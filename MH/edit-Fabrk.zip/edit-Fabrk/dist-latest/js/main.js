var $body,
	windowHeight,
	windowWidth,
	$menuTrigger,
	$peopleSlider,
	degree = 0.0174532925,
	mediaPoint1 = 1024,
	mediaPoint2 = 768,
	mediaPoint3 = 480,
	mediaPoint4 = 320,
	locationToBlock = 'US',
	redirectUrl = 'http://www.google.com',
	accessKey = 'df31447a68eef2df3b1db52f4fb33548';

$(document).ready(function ($) {
	
	$body = $('body');
	$menuTrigger = $('.menuTrigger');
	$peopleSlider = $('.team_people_group')
	$popupWrap = $('.popup_wrap');


	$menuTrigger.on('click', function () {
		if ($body.hasClass('menu_open')) {
			$body.removeClass('menu_open');
			$(this).removeClass('active_mod');
		} else {
			$body.addClass('menu_open');
			$(this).addClass('active_mod');
		}
	});

	//developer funcitons
	//pageWidget(['index']);
	//getAllClasses('html','.elements_list');

	$('.popupClose').on('click', function() {
		$body.removeClass('menu_open');
		$popupWrap.removeClass('active_mod');
	});

	$('.team_slider').slick({
		slidesToShow: 1,
		slidesToScroll: 1,
		dots: false,
		arrows: true,
		prevArrow: '.team_slider_btn.prev_mod',
		nextArrow: '.team_slider_btn.next_mod',
		autoplay: false,
		fade: true,
		cssEase: 'linear'
	});

	$('.team_person').on('click', function (e) {
		let $curPersonId = $(e.currentTarget).data('target');

		if ($popupWrap.hasClass('active_mod')) {
			$popupWrap.removeClass('active_mod');
		} else {
			$popupWrap.addClass('active_mod');
			$('.team_slider').slick('slickGoTo', parseInt($curPersonId));
		}
	})
});

$(window).on('load', function () {
	updateSizes();
	loadFunc();
});

$(window).on('resize', function () {
	resizeFunc();
});

$(window).on('scroll', function () {
	scrollFunc();
});

function loadFunc() {
	calcViewportHeight();
	teamMobileSlider();

	window.dima = baron({
		root: '.baron',
		scroller: '.baron__scroller',
		bar: '.baron__bar'
	}).autoUpdate();
}

function resizeFunc() {
	updateSizes();
	teamMobileSlider();

	calcViewportHeight();
}

function scrollFunc() {
}

function calcViewportHeight() {
	if (isMobile.apple.phone || isMobile.android.phone || isMobile.seven_inch) {
		var vh = window.innerHeight * 0.01;
		// var vh2 = document.documentElement.clientHeight * 0.01;

		document.documentElement.style.setProperty('--vh', vh + 'px');
	}
}

function updateSizes() {
	windowWidth = window.innerWidth;
	windowHeight = window.innerHeight;
}

if ('objectFit' in document.documentElement.style === false) {
	document.addEventListener('DOMContentLoaded', function () {
		Array.prototype.forEach.call(document.querySelectorAll('img[data-object-fit]'), function (image) {
			(image.runtimeStyle || image.style).background = 'url("' + image.src + '") no-repeat 50%/' + (image.currentStyle ? image.currentStyle['object-fit'] : image.getAttribute('data-object-fit'));

			image.src = 'data:image/svg+xml,%3Csvg xmlns=\'http://www.w3.org/2000/svg\' width=\'' + image.width + '\' height=\'' + image.height + '\'%3E%3C/svg%3E';
		});
	});
}

function getRandomInt(min, max) {
	return Math.floor(Math.random() * (max - min)) + min;
}

function getRandom(min, max) {
	return Math.random() * (max - min) + min;
}

const styles = ['color: #fff', 'background: #cf8e1f'].join(';');

const message = 'Developed by Glivera-team https://glivera-team.com/';

console.info('%c%s', styles, message);


function teamMobileSlider() {
	if (windowWidth <= mediaPoint1) {
		console.log('yes');
		if (!$peopleSlider.hasClass('slick-slider')) {
			peopleSlider();
		}
	} else {
		console.log('no');
		if ($peopleSlider.hasClass('slick-initialized')) {
			$peopleSlider.slick("unslick");
		}
	}
}

function peopleSlider() {
	$peopleSlider.slick({
		infinite: true,
		slidesToShow: 1,
		slidesToScroll: 1,
		dots: false,
		arrows: true,
		centerMode: true,
		mobileFirst: true,
		adaptiveHeight: true,
		variableWidth: true,
		initialSlide:2,
		prevArrow: '.team_people_arrow.prev_mod',
		nextArrow: '.team_people_arrow.next_mod',
	});
	
	
	
}


