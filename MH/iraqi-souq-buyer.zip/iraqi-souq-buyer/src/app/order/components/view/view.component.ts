import { Component, OnInit } from '@angular/core';
import { OrderService } from '../../services/order.service';
import { Router, ActivatedRoute } from '@angular/router';
import { NgbModal, NgbModalOptions } from '@ng-bootstrap/ng-bootstrap';
import { RefundModalComponent } from '../refundModal/refund-modal.component';

@Component({
  selector: 'order-view',
  templateUrl: './view.html'
})
export class ViewComponent implements OnInit {

  public isSubmitted: boolean = false;
  public order: any = {};
  public details: any = [];

  constructor(private router: Router, private route: ActivatedRoute, private orderService: OrderService, private modalService: NgbModal) {
    this.order = this.route.snapshot.data.order;
    this.details = this.route.snapshot.data.order.details;

    // update tax price by user currency!
    this.details.forEach((detail) => {
      const currencyExchange = detail.currencyExchangeRate || 1;
      detail.taxPrice = currencyExchange * (detail.taxPrice || 0);
      detail.shippingPrice = currencyExchange * (detail.shippingPrice || 0);
    });
  }

  ngOnInit() {
  }

  openRefund(item) {
    let ngbModalOptions: NgbModalOptions = {
      backdrop: 'static',
      keyboard: false
    };
    const modalRef = this.modalService.open(RefundModalComponent, ngbModalOptions);
    modalRef.componentInstance.orderDetailId = item._id;
  }

}
