import { Injectable, ViewContainerRef } from '@angular/core';
import { Subject } from 'rxjs/Subject';
import { Restangular } from 'ngx-restangular';
import 'rxjs/add/operator/toPromise';
import * as _ from 'lodash';
import { ToastyService } from 'ng2-toasty';
import { SystemService } from './system.service';
import { ToastrManager } from 'ng6-toastr-notifications';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root',
})
export class CartService {
  private cartChanged = new Subject<any>();
  private cart: any = [];
  public cartChanged$ = this.cartChanged.asObservable();

  constructor(private restangular: Restangular, public toastr: ToastrManager,
    private toasty: ToastyService, private systemService: SystemService) {
    // TODO - load cart from local storage
    const cartData = localStorage.getItem('cart');
    this.cart = cartData ? JSON.parse(cartData) : [];
    this.cartChanged.next(this.cart);
  }

  get() {
    return this.cart;
  }

  cartAlertToast(productName: String) {
    this.toastr.successToastr(
      `<span style='color:#299C77'><i style="margin-right: 2em;font-size: 1.35em;" class="fa fa-check"></i><b>'${productName}'</b> has been added to cart.</span>&nbsp;&nbsp;<button class="btn">View Cart</button>`,
      null, {
        data: { url: '/cart/checkout' },
        position: 'bottom-full-width',
        maxShown: 1,
        animate: 'slideFromBottom',
        enableHTML: true,
        //dismiss: 'controlled',
        showCloseButton: true
      });
  }

  add(data: any, quantity: number) {
    console.log('data: ', data);
    return new Promise((resolve, reject) => {

      this.toastr.onClickToast()
        .subscribe((toast: any) => {
          console.log('toast: ', toast);
          if (toast.data && toast.data.url) {
            resolve(true);
          }
        });

      const existProduct = _.find(this.cart, (c: any) => c.productId === data.productId);
      if (existProduct && data.productVariantId === existProduct.productVariantId) {
        quantity += existProduct.quantity;

        _.remove(this.cart, (n: any) => {
          return n.productId === data.productId;
        });
        this.cartAlertToast(data.product.name);

      } else {
        // this.toasty.success('This item has been added to cart.');
        this.cartAlertToast(data.product.name);
      }

      // TODO - not duplicate for existing product
      this.cart.unshift({
        productId: data.productId,
        productVariantId: data.productVariantId,
        product: data.product,
        quantity
      });
      localStorage.setItem('cart', JSON.stringify(this.cart));
      this.cartChanged.next(this.cart);
    });
  }

  remove(product: any) {
    const index = _.findIndex(this.cart, (c: any) => c.productId === product.productId);
    if (index > -1) {
      this.cart.splice(index, 1);
    }

    localStorage.setItem('cart', JSON.stringify(this.cart));
    this.cartChanged.next(this.cart);
  }

  clean() {
    this.cart = [];
    localStorage.setItem('cart', JSON.stringify([]));
    this.cartChanged.next([]);
  }

  checkout(params: any): Promise<any> {
    return this.restangular.one('orders').customPOST(params).toPromise();
  }

  verifyCOD(params: any): Promise<any> {
    return this.restangular.one('orders', 'phone', 'check').customPOST(params).toPromise();
  }

  updateQuantity(product: any, quantity: any) {
    const index = _.findIndex(this.cart, (c: any) => c.productId === product.productId);
    if (index > -1) {
      this.cart[index].quantity = quantity;
    }

    localStorage.setItem('cart', JSON.stringify(this.cart));
    this.cartChanged.next(this.cart);
  }


  calculate(): Promise<any> {
    return this.systemService.configs().then(systemConfig => {
      if (!this.cart || !this.cart.length) {
        return Promise.resolve({
          products: [],
          userCurrency: systemConfig.customerCurrency
        });
      }
      return this.restangular.one('cart', 'calculate').customPOST({
        products: this.cart.map(product => _.pick(product, ['productId', 'productVariantId', 'quantity'])),
        userCurrency: systemConfig.customerCurrency
      }).toPromise();
    });
  }
}
