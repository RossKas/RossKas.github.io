import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { ToastyService } from 'ng2-toasty';
// import { StaticPageService } from '../services/static-page.service';
import { TranslateService } from '@ngx-translate/core';
import {StaticPageService} from '../../../static-page/services/static-page.service';
import {AuthService} from '../../../shared/services/auth.service';

@Component({
  selector: 'addresses',
  templateUrl: './addresses.html',
  styleUrls: ['./addresses.css']
})
export class AddressesComponent implements OnInit {
  public page: any = {};
  public address: any [];
  public userAllAddress: any [];

  constructor(private toasty: ToastyService, private translate: TranslateService, private router: Router, private route: ActivatedRoute, private auth: AuthService) {
  }

  ngOnInit() {
    this.userAddresses();
  }

  userAddresses() {
    this.auth.getUserAddresses().then((resp) => {
      this.userAllAddress = resp.data;
      console.log(this.userAllAddress);
    });
  }

  deleteAddress(addrId: any, index: number) {
    if (window.confirm(this.translate.instant('Are you sure want to remove this Address?'))) {
      this.auth.delete(addrId)
        .then(() => {
          this.toasty.success(this.translate.instant('Address has been removed!'));
          this.userAllAddress.splice(index, 1);
        })
        .catch((err) => this.toasty.error(this.translate.instant('Something went wrong, please try again!')));
    }
  }
}
