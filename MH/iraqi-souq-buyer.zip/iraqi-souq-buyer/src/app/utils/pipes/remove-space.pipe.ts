import { Pipe, PipeTransform } from '@angular/core';
import { CurrencyService } from '../services/currency.service';

/*
 * format price with user currency
*/
@Pipe({
  name: 'removeSpace'
})
export class RemoveSpacePipe implements PipeTransform {
  constructor() { }

  transform(value: string): any {
    return value.replace(/[^\w\s]/gi, '').split(' ').join('-');
  }
}
