import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { CartService } from '../services';
import { Subscription } from 'rxjs/Subscription';

@Component({
  selector: 'search-bar',
  templateUrl: './search-bar.html'
})
export class SearchbarComponent implements OnInit {
  public q: string = '';
  private cartLoadedSubscription: Subscription;
  public cart: any = [];

  constructor(public router: Router, private cartService: CartService) {
    this.cartLoadedSubscription = cartService.cartChanged$.subscribe(data => this.cart = data);
  }

  ngOnInit() {
    this.cart = this.cartService.get();
  }

  keyPress(event: any) {
    if (event.charCode === 13) {
      this.search();
    }
  }

  search() {
    if (!this.q.trim()) {
      return;
    }

    // nativate to search page
    this.router.navigate(['/products/search'], {
      queryParams: { q: this.q }
    });
  }
}
