import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { CategoryService, ProductService, BrandService } from '../../services';
import { ShopService } from '../../../shop/services/shop.service';
import * as _ from 'lodash';
import { isArray } from 'util';

@Component({
  selector: 'search-sidebar',
  templateUrl: './search-sidebar.html'
})
export class SearchSidebarComponent implements OnInit {

  @Output() updateFields = new EventEmitter();
  public tree: any = [];
  public shops: any = [];
  public items: any = [];
  public brands: any = [];
  public _filters: any = [];
  public foundBrand: any;
  public brandFilters: any = [];
  public page: any = 1;
  public itemsPerPage: any = 12;
  public options: any = [];
  public filteredOptions: any = [];
  public selectedItems: any = [];
  public selectedCategory: any;
  filtered = [];

  public searchFields: any = {
    checks: [],
    brands: []
  };
  public filterAll = false;
  public routeId: any = {
    categoryId: '',
    shopId: ''
  };
  public valuesArr: any = [];

  constructor(private route: ActivatedRoute, private router: Router, private categoryService: CategoryService,
    private shopService: ShopService, private productService: ProductService, private brandService: BrandService) {
    this.route.queryParams.subscribe(data => {
      this.routeId.categoryId = data.categoryId;
      this.routeId.shopId = data.shopId;
      this.getbrands();
      if (this.tree.length) {
        this.selectedCategory = this.categoryService.findInTree(this.tree, this.routeId.categoryId);
      }
      this.productService.OptionsSearch({ categoryId: this.routeId.categoryId }).then((resp) => {
        this.options = resp.data.items.sort((a, b) => {
          a = a._id[0].ordinal;
          b = b._id[0].ordinal;
          return a > b ? -1 : b > a ? 1 : 0;
        }).reverse();
        this.filteredOptions = this.parseParentOptions(resp.data.items.slice(), '');
      });
    });
  }

  @Input()
  set filters(filters: any) {
    this._filters = filters;
  }

  @Input()
  set cateIdFromSearchProd(cateIdFromSearchProd: any) {
    // this.getbrands();
    if (cateIdFromSearchProd) {
      this.productService.OptionsSearch({ categoryId: cateIdFromSearchProd }).then((resp) => {
        this.options = resp.data.items.sort((a, b) => {
          a = a._id[0].ordinal;
          b = b._id[0].ordinal;
          return a > b ? -1 : b > a ? 1 : 0;
        }).reverse();
        this.filteredOptions = this.parseParentOptions(resp.data.items.slice(), '');
      });
    }
  }

  test(id) {
    const val = 0;
  }

  parseParentOptions(arr: any, currentId: any) {
    const resultArray: any[] = [];

    if (arr) {
      // const valuesArr: any = Object.values(this.selectedItems).flat().map(a => a.id) || [];

      // const newArray = arr.filter((obj, pos, filArr) => {
      //   return obj.values.filter(x => x.groups.length < 1 ||
      //     x.groups.flat().filter(y => valuesArr.indexOf(y.parentId) > -1).length > 0).length > 0;
      // }) || [];

      for (let index = 0; index < arr.length; index++) {

        if (!arr[index]._id[0].showOnFilter) {
          continue;
        }
        const element = Object.assign({}, arr[index]);
        element.values = this.parseValues(
          this.options.slice().find(x => x._id[0].key === element._id[0].key).values,
          this.valuesArr, currentId);
        resultArray.push(element);
      }
    }
    return resultArray;
  }

  parseValues(valuesArr: any[], selected: any[], currentId: any) {

    if (selected.indexOf(currentId) < 0) {
      return valuesArr;
    }

    const newArray = valuesArr.filter((obj, pos, filArr) => {
      return obj.groups.length < 1 ||
        obj.groups.flat().filter(x => x.parentId === currentId || selected.indexOf(x.parentId) > -1).length > 0;
    }) || [];

    if (newArray.length > 0) {
      return newArray;
    } else {
      return valuesArr;
    }
  }

  onCategoryChange(category: any) {
    this.selectedCategory = category;
    this.router.navigate(['/products/search'], {
      queryParams: { categoryId: category.id }
    });
  }

  onFeatureChange(id: any, key: any) {

    if (this.searchFields.checks[key] === true) {
      this.selectedItems.push({ id: id });
      this.valuesArr.push(id);
    } else {
      const index = this.selectedItems.findIndex((x) => {
        return x.id === id;
      });
      this.selectedItems.splice(index, 1);
      this.valuesArr.splice(index, 1);
    }

    this.filteredOptions = this.parseParentOptions(this.options.slice(), id);
    this.filter();
  }

  // onFeatureChange() {
  //   console.log(this.selectedItems);
  //   if (this.selectedItems) {
  //     for (let i in this.selectedItems) {
  //       var list = [];
  //       if (isArray(this.selectedItems[i])) {
  //         this.selectedItems[i].map((l) => {
  //           list.push(l.hasOwnProperty('displayText') ? l.displayText : l);
  //         })
  //       } else {
  //         list.push(this.selectedItems[i].hasOwnProperty('displayText') ? this.selectedItems[i].displayText : this.selectedItems[i]);
  //       }
  //     }
  //     this.filteredOptions = this.parseParentOptions(this.options.slice());
  //   }
  // }


  onKeydown(event) {
    if (event.key === 'Enter') {
      this.filter();
    }
  }

  ngOnInit() {
    this.categoryService.tree().then(resp => {
      this.tree = resp;
      this.selectedCategory = this.categoryService.findInTree(this.tree, this.routeId.categoryId);
    });
    this.shopService.search({ take: 20, featured: 1 }).then(resp => this.shops = resp.data.items);
    this.getbrands();
  }

  getbrands() {
    if (this.routeId.categoryId) {
      this.brandService.search({ categoryId: this.routeId.categoryId })
        .then(resp => {
          this.brands = resp.data.items;
        })
        .catch(() => { });
    }
  }

  fetchFilters(list: any, key: any) {
    const found = _.find(list, { key: key });
    return found['value'];
  }

  filter() {
    const checkedBrands = this.searchFields.brands ? { ...this.searchFields.brands } : {};
    this.brandFilters = [];
    const keys = Object.keys(checkedBrands);
    keys.map((l, i) => {
      if (checkedBrands[l] === true) {
        this.foundBrand = _.find(this.brands, { _id: l });
        this.brandFilters.push(this.foundBrand);
      }
    });

    if (this.filterAll ||
      !this.searchFields.featured &&
      !this.searchFields.hot &&
      !this.searchFields.bestSell &&
      !this.searchFields.discounted &&
      !this.searchFields.dailyDeal && !this.searchFields.soldOut
      && !this.searchFields.checks
    ) {
      this.searchFields = {
        featured: '',
        hot: '',
        bestSell: '',
        dailyDeal: '',
        discounted: '',
        soldOut: ''
      };
    }
    console.log(this.searchFields);
    this.updateFields.emit(this.searchFields);

  }
}
