import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { ToastyService } from 'ng2-toasty';
import { StaticPageService } from '../services/static-page.service';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'static-page',
  templateUrl: './view.html'
})
export class StaticPageComponent implements OnInit {
  public page: any = {};

  constructor(private translate: TranslateService, private router: Router, private route: ActivatedRoute, private toasty: ToastyService, private staticpageService: StaticPageService) {
    this.route.params.subscribe(data => {
      this.staticpageService.find(data.alias).then((res) => {
        this.page = res.data;
      })
        .catch(() => this.toasty.error(this.translate.instant('Something went wrong, please try again!')));
    });

  }

  ngOnInit() {
  }
}