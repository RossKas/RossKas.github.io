import { Component, OnInit, Input } from '@angular/core';
import { Router } from '@angular/router';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { ToastyService } from 'ng2-toasty';
import { TranslateService } from '@ngx-translate/core';

@Component({
  templateUrl: './form.html'
})
export class CodVerifyModalComponent implements OnInit {
  public verifyCode: string;

  constructor(private translate: TranslateService, private router: Router,
    private toasty: ToastyService, public activeModal: NgbActiveModal) {
  }

  ngOnInit() { }

  confirm() {
    if (!this.verifyCode) {
      return this.toasty.error(this.translate.instant('Please enter verify code!'));
    }
    this.activeModal.close({
      verifyCode: this.verifyCode
    });
  }
}
