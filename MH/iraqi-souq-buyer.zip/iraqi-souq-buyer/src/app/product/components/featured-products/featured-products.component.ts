import { Component, OnInit, Input, OnChanges } from '@angular/core';
import { ToastyService } from 'ng2-toasty';
import { ProductService } from '../../services';
import * as _ from 'lodash';

@Component({
  selector: 'featured-products',
  templateUrl: './featured-products.html'
})
export class FeaturedProductsComponent implements OnInit, OnChanges {
  @Input() options: any = '';
  public items: any = [];
  public page: any = 1;
  public itemsPerPage: any = 40;
  public searchFields: any = {};
  public sort: any = 'random';
  public sortType: any = '';
  public show = 20;
  public counter: number;
  public content: any = [];

  constructor(private toasty: ToastyService, private productService: ProductService) { }

  ngOnInit() {
    this.query();
  }
  showmore() {
    this.show += 2;
  }
  getData() {
    console.log(this.counter + 'data size' + this.items.length);

    for (let i = this.counter + 1; i < this.items.length; i++) {
      this.content.push(this.items[i]);
      if (i % 2 === 0) {
        break;
      }
    }
    this.counter += 2;

  }

  ngOnChanges() {
    this.items = [];
    this.query();
    this.featuredQuery();
  }

  query() {
    if (this.options.productId) {
      this.relatedQuery();
    } else {
      this.featuredQuery();
    }
  }

  featuredQuery() {
    const params = Object.assign({
      page: this.page,
      take: this.itemsPerPage,
      sort: this.sort,
      sortType: this.sortType
    }, this.options);

    this.productService.search(params).then((res) => {
      this.items = res.data.items;
    });
  }

  relatedQuery() {
    let params = {
      page: this.page,
      take: this.itemsPerPage
    };

    this.productService.related(this.options.productId, params).then((res) => {
      this.items = res.data;
    });
  }
  // showmore() {
  //   this.show += 1;
  // }
  // increaseShow() {
  //   this.show += 2;
  // }
}
