import { Component, OnInit, Input } from '@angular/core';
import { ToastyService } from 'ng2-toasty';
import { ShopService } from '../../services/shop.service';
// import { LocationService } from '../../../shared/services/location.service';
import { TranslateService } from '@ngx-translate/core';
import * as _ from 'lodash';

@Component({
  selector: 'search-shops',
  templateUrl: './search.html'
})
export class SearchComponent implements OnInit {
  public shops: any = [];
  public page: Number = 1;
  public itemsPerPage: Number = 12;
  public searchFields: any = {
    q: ''
  };
  public total: any = 0;
  public countries: any = [];
  public states: any = [];
  public cities: any = [];
  public distance: any = '';
  public map: any = {
    distance: '',
    latitude: '',
    longitude: ''
  };

  constructor(private translate: TranslateService, private toasty: ToastyService, private shopService: ShopService) {

  }

  ngOnInit() {
    // this.location.countries().then(resp => this.countries = resp.data);
    this.query();
  }

  query() {
    const params = Object.assign({
      page: this.page,
      take: this.itemsPerPage
    }, this.searchFields);

    if (this.map.distance && this.map.latitude && this.map.longitude) {
      params.latitude = this.map.latitude;
      params.longitude = this.map.longitude;
      params.distance = this.map.distance;
    }

    this.shopService.search(params).then((res) => {
      this.shops = res.data.items;
      this.total = res.data.count;
    })
      .catch(() => this.toasty.error(this.translate.instant('Something went wrong, please try again!')));
  }

  queryLocation() {
    const params = Object.assign({
      take: 100
    }, this.searchFields);
    if (this.map.distance && this.map.latitude && this.map.longitude) {
      params.latitude = this.map.latitude;
      params.longitude = this.map.longitude;
      params.distance = this.map.distance;
    }
    this.shopService.search(params).then((res) => {
      this.shops = res.data.items;
      this.total = 0;
    })
      .catch(() => this.toasty.error(this.translate.instant('Something went wrong, please try again!')));
  }

  trackLocation() {
    let that = this;
    const res = function success(pos) {
      if (pos && pos.coords && pos.coords.latitude && pos.coords.longitude) {
        that.map.latitude = pos.coords.latitude;
        that.map.longitude = pos.coords.longitude;
        that.queryLocation();
      }
    };

    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(res);
    } else {
      this.toasty.error('Geolocation is not supported by this browser.');
    }

  }

  keyPress(event: any) {
    if (event.charCode === 13) {
      this.query();
    }
  }

}
