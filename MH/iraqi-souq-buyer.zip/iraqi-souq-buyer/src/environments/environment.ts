// The file contents for the current environment will overwrite these during build.
// The build system defaults to the dev environment which uses `environment.ts`, but if you do
// `ng build --env=prod` then `environment.prod.ts` will be used instead.
// The list of which env maps to which file can be found in `.angular-cli.json`.

export const environment = {
  production: false,
  version: '0.0.1',
  build: 15,
  //apiBaseUrl: 'http://localhost:9000/v1',
  apiBaseUrl: 'http://35.182.190.14:9000/v1',
  sellerUrl: 'http://seller.iraqisoug.com',
  // shopUrl: 'http://35.182.190.14/seller',
  // sellerUrl: 'https://genstore-seller.iospot.top',
  platform: 'web',
  googleClientId: '946463315327-0l0svqeglss2jrulg19t9hs5slem6247.apps.googleusercontent.com',
  facebookAppId: '309990489726708',
  paymentRedirectSuccessUrl: 'http://localhost:4200/cart/checkout/success',
  paymentRedirectCancelUrl: 'http://localhost:4200',
  stripeKey: 'pk_test_QPvRQBd3zG4eguqFuJukaKRB',
  pusher: {
    appId: 591974,
    key: '8cbf727dad3c8ce84888',
    cluster: 'ap1'
  }
};
