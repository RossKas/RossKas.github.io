import { Component, OnInit, Input } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { ToastyService } from 'ng2-toasty';
import { SeoService, AuthService, ReviewService } from '../../../shared/services';
import { ShopService } from '../../services/shop.service';
import { ProductService } from '../../../product/services/product.service';
import { NgbModal, NgbModalOptions } from '@ng-bootstrap/ng-bootstrap';
import { ReportComponent } from '../report/report.component';
import { TranslateService } from '@ngx-translate/core';

@Component({
  templateUrl: './detail.html'
})
export class ShopDetailComponent implements OnInit {
  public shop: any;
  public products = [];
  public page: number = 1;
  public take: number = 15;
  public totalProducts: number = 0;
  public isLoading: Boolean = false;
  public searchFields: any = {
    q: ''
  };
  public tab = 'products';
  public socialLink: boolean = false;

  constructor(private translate: TranslateService, private auth: AuthService,
    private router: Router, private route: ActivatedRoute,
    private seoService: SeoService, private reviewService: ReviewService, private shopService: ShopService,
    private productService: ProductService, private toasty: ToastyService,
    private modalService: NgbModal) {
    // shop form resolver
    this.shop = this.route.snapshot.data.shop;
    if (this.shop.socials.facebook && this.shop.socials.google &&
      this.shop.socials.twitter && this.shop.socials.linkedin &&
      this.shop.socials.youtube && this.shop.socials.instagram &&
      this.shop.socials.flickr) {
      this.socialLink = true;
    }
  }

  ngOnInit() {
    this.seoService.update(this.shop.name, {});

    this.query();
  }

  query() {
    let params = Object.assign({
      shopId: this.shop.id,
      page: this.page,
      take: this.take
    }, this.searchFields);

    this.productService.search(params).then((res) => {
      this.products = res.data.items;
      this.totalProducts = res.data.count;
    })
      .catch(() => this.toasty.error(this.translate.instant('Something went wrong, please try again!')));
  }

  keyPress(event: any) {
    if (event.charCode === 13) {
      this.query();
    }
  }

  report() {
    if (!this.auth.isLoggedin()) {
      return this.toasty.error(this.translate.instant('You have to log in first.'));
    }
    let ngbModalOptions: NgbModalOptions = {
      backdrop: 'static',
      keyboard: false
    };
    const modalRef = this.modalService.open(ReportComponent, ngbModalOptions);
    modalRef.componentInstance.shopId = this.shop.id;
  }
}
