import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { ToastyService } from 'ng2-toasty';
// import { StaticPageService } from '../services/static-page.service';
import { TranslateService } from '@ngx-translate/core';
import {StaticPageService} from '../../../static-page/services/static-page.service';
import {AuthService} from '../../../shared/services/auth.service';

@Component({
  selector: 'notifications',
  templateUrl: './notifications.html',
  styleUrls: ['./notifications.css']
})
export class NotificationComponent implements OnInit {
  public page: any = {};
  public notification: any = {};
  public savedNotificationSetting: any = {};

  constructor(private translate: TranslateService, private toasty: ToastyService, private router: Router, private route: ActivatedRoute, private auth: AuthService) {
  }

  ngOnInit() {
    // this.postNotificationSettings();
  }

  postNotificationSettings() {
    this.auth.saveNotification({
      isEmailNewsletter : this.notification.isEmailNewsletter,
      isEmailDeals : this.notification.isEmailDeals,
      isEmailOffers : this.notification.isEmailOffers,
      isSmsNotification : this.notification.isSmsNotification,
    }).then((resp) => {
      this.savedNotificationSetting = resp;
      this.toasty.success(this.translate.instant('Saved Notification Settings!!'));
      // console.log(this.savedNotificationSetting);
    });
  }
}
