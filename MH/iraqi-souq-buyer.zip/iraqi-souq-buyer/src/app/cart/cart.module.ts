import { NgModule, NO_ERRORS_SCHEMA } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { NgxStripeModule } from 'ngx-stripe';
import { UtilsModule } from '../utils/utils.module';
import { MatTabsModule, MatStepperModule} from '@angular/material';
import { NbStepperModule, NbLayoutModule} from '@nebular/theme';

import {
  CheckoutComponent,
  // CheckoutDetailComponent,
  CheckoutSuccessComponent,
  CodVerifyModalComponent
} from './components';

import { NoPhotoPipe } from '../shared/pipes';
import { ConfigResolver } from '../shared/resolver';
import { OrderService } from '../order/services/order.service';
import { TransactionService } from './services/transaction.service';

import { CartResolver } from './resolvers/cart.resolver';
import {ProductService} from '../product/services/product.service';
import {FeaturedProductsComponent} from '../product/components/featured-products/featured-products.component';
import {ProductDetailComponent} from '../product/components/detail/detail.component';
import {ProductCardComponent} from '../product/components/product-card/product-card.component';
import {SearchSidebarComponent} from '../product/components/search-sidebar/search-sidebar.component';
import {SearchComponent} from '../product/components/search/search.component';
import {BrandService} from '../product/services/brand.service';
import {CategoryService} from '../product/services/category.service';
import {ProductResolver} from '../product/resolvers/product.resolver';
import {SearchResolver} from '../product/resolvers/search.resolver';
import {ProductVariantService} from '../product/services/variant.service';
import {ReviewService} from '../shared/services/review.service';
import {WishlistService} from '../profile/services/wishlist.service';
import {ProductModule} from '../product/product.module';
import {CurrencyPipe} from '../shared/pipes/currency.pipe';
import {CheckoutDetailComponent} from './components/checkout-detail/checkout-detail.component';
import {AuthGuard} from '../shared/guard/auth.guard';
import {ListingComponent} from '../order/components/listing/listing.component';

const routes: Routes = [{
  path: 'checkout',
  component: CheckoutComponent,
  resolve: {
    appConfig: ConfigResolver,
    cart: CartResolver
  }
},
{
  path: 'checkout-detail',
  component: CheckoutDetailComponent,
  canActivate: [AuthGuard],
  resolve: {
    appConfig: ConfigResolver,
    cart: CartResolver
  }
},

{
  path: 'checkout/success',
  component: CheckoutSuccessComponent
}
// {
//   path: 'orders/list',
//   component: ListingComponent
// },
];

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    NbStepperModule,
    NbLayoutModule,
    MatTabsModule,
    MatStepperModule,
    NgbModule,
    RouterModule.forChild(routes),
    UtilsModule,
    NgxStripeModule.forRoot()
  ],
  exports: [

  ],
  declarations: [
    CheckoutComponent,
    CheckoutDetailComponent,
    CheckoutSuccessComponent,
    CodVerifyModalComponent,
    NoPhotoPipe,
    // ProductDetailComponent,
    // FeaturedProductsComponent,
    // ProductCardComponent,
    // SearchSidebarComponent,
    // SearchComponent,
    // CurrencyPipe
  ],
  entryComponents: [
    CodVerifyModalComponent
  ],
  providers: [
    OrderService,
    TransactionService,
    CartResolver,
    BrandService,
    CategoryService,
    ProductService,
    ProductResolver,
    SearchResolver,
    ProductVariantService,
    ReviewService,
    WishlistService
  ]
})

export class CartModule { }
