import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ProductDetailComponent } from './components/detail/detail.component';
import { ProductResolver } from './resolvers/product.resolver';
import { SearchResolver } from './resolvers/search.resolver';
import { SearchComponent } from './components/search/search.component';
import { AuthGuard } from '../shared/guard/auth.guard';
import { ProductCategoriesComponent } from './components/product-categories/product-categories.component';

const routes: Routes = [
  {
    path: 'categories',
    component: ProductCategoriesComponent
  },
  {
    path: 'search',
    component: SearchComponent,
    resolve: {
      search: SearchResolver
    }
  },
  {
    path: ':alias',
    component: ProductDetailComponent,
    // canActivate: [AuthGuard],
    resolve: {
      product: ProductResolver
    }
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ProductRoutingModule { }
