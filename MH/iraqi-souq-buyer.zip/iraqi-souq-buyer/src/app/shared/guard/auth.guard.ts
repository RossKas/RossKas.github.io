import { Injectable } from '@angular/core';
import {ActivatedRouteSnapshot, CanActivate, RouterStateSnapshot} from '@angular/router';
import { Router } from '@angular/router';
import { AuthService } from '../services';
// import {state} from "@angular/animations";

@Injectable()
export class AuthGuard implements CanActivate {

  constructor(private router: Router, private Auth: AuthService) { }

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
    if (!this.Auth.isLoggedin()) {
      this.router.navigate(['/auth/login'], { queryParams: { returnUrl : state.url }});
      return false;
      // console.log(state.url);
    }

    return this.Auth.getCurrentUser()
      .then(resp => {
        const canActive = resp !== null;
        if (!canActive) {
          this.router.navigate(['/auth/login'], { queryParams: { returnUrl: state.url }});
          return false;
          // console.log(returnUrl);
        }

        return true;
      });
  }
}
