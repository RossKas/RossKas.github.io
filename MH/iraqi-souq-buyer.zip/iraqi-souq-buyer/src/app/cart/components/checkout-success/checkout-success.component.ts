import { Component } from '@angular/core';
import { CartService } from '../../../shared/services';

@Component({
	templateUrl: './checkout-success.html'
})
export class CheckoutSuccessComponent {
	constructor(private service: CartService) {
		service.clean();
	}
}
