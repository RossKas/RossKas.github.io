import {Component, OnInit, Input, Output, EventEmitter, OnChanges} from '@angular/core';
import * as _ from 'lodash';
import { ReviewService, AuthService } from '../../../shared/services';

@Component({
  selector: 'review-list',
  templateUrl: './list.html'
})
export class ReviewListComponent implements OnInit, OnChanges {
  @Input() options: any;
  public page: any = 1;
  public pageSize: any = 10;
  public items: any = [];
  public total: any = 0;
  public ratings: any = [0, 0, 0, 0, 0];
  public show = 2;
  public showMore = false;

  constructor(private reviewService: ReviewService) { }

  ngOnChanges() {
    this.page = 1;
    this.items = [];
    this.query();
  }

  ngOnInit() {
    console.log(this.options);
    this.query();
  }
  showmore() {
    this.show += 1;
  }
  query() {
    this.reviewService.search(Object.assign({
      page: this.page,
      take: this.pageSize
    }, this.options)).then((res) => {
      res.data.breakDown.forEach(r => {
          this.ratings[r._id] = r.count;
      });
      this.items = res.data.items;
      this.total = res.data.count;
      console.log(res.data);
    });
  }

  percentage(value: any) {
    return value * 100 / this.total;
  }

  onRating(event: any) {
    this.items.unshift(event);
    this.total += 1;
  }
}
