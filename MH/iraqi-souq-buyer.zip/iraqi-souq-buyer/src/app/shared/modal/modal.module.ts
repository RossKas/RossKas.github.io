import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import {NgbModalModule, NgbModule} from '@ng-bootstrap/ng-bootstrap';
import { ShareModule } from '@ngx-share/core';

import {MatExpansionModule} from '@angular/material/expansion';

import { NgxImageZoomModule } from 'ngx-image-zoom';
import { SlickCarouselModule } from 'ngx-slick-carousel';





import { MatTabsModule, MatStepperModule} from '@angular/material';
import {SearchSidebarComponent} from '../../product/components/search-sidebar/search-sidebar.component';
import {ProductCardComponent} from '../../product/components/product-card/product-card.component';
import {FeaturedProductsComponent} from '../../product/components/featured-products/featured-products.component';
import {WishlistService} from '../../profile/services/wishlist.service';
import {ReviewService} from '../services/review.service';
import {ProductVariantService} from '../../product/services/variant.service';
import {SearchResolver} from '../../product/resolvers/search.resolver';
import {ProductResolver} from '../../product/resolvers/product.resolver';
import {ProductService} from '../../product/services/product.service';
import {CategoryService} from '../../product/services/category.service';
import {BrandService} from '../../product/services/brand.service';
import {CurrencyPipe} from '../pipes/currency.pipe';
import {SearchComponent} from '../../product/components/search/search.component';
import {ProductDetailModalComponent} from './product-detail-modal/detail-modal.component';
import {MessageModule} from '../../message/message.module';
import {UtilsModule} from '../../utils/utils.module';
import {CartModule} from '../../cart/cart.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    NgbModule.forRoot(),
    NgxImageZoomModule.forRoot(),
    ShareModule.forRoot(),
    CartModule,
    UtilsModule,
    SlickCarouselModule,
    MessageModule,
    MatTabsModule,
    MatExpansionModule,
    NgbModalModule
  ],
  declarations: [
   // ProductDetailModalComponent,
    // FeaturedProductsComponent,
    // ProductCardComponent,
    // SearchSidebarComponent,
    // SearchComponent,
    // CurrencyPipe
  ],
  providers: [
    BrandService,
    CategoryService,
    ProductService,
    ProductResolver,
    SearchResolver,
    ProductVariantService,
    ReviewService,
    WishlistService
  ],
  // entryComponents: [
  //   ProductDetailModalComponent
  // ],
  exports: [
    //ProductDetailModalComponent,
    // FeaturedProductsComponent,
    // ProductCardComponent,
    // SearchSidebarComponent,
    // SearchComponent
  ]
})
export class ModalModule { }
