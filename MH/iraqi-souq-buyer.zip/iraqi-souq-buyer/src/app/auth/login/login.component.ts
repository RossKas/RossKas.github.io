import {Component, OnInit} from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';
import { AuthService } from '../../shared/services';
import { TranslateService } from '@ngx-translate/core';
import { ToastyService } from 'ng2-toasty';

@Component({
  templateUrl: 'login.component.html',
  styleUrls: ['./../auth.css']
})
export class LoginComponent implements OnInit {
  private Auth: AuthService;
  public returnUrl: any = '';
  private err: any;
  public credentials = {
    email: '',
    password: ''
  };
  public submitted: boolean = false;

  constructor(private route: ActivatedRoute, auth: AuthService, public router: Router, private translate: TranslateService, private toasty: ToastyService) {
    this.Auth = auth;
  }
  ngOnInit() {
    // get return url from route parameters or default to '/'
    this.route.queryParams
      .subscribe(params => this.returnUrl = params['returnUrl'] || '/');

}

  login(frm: any) {
    this.submitted = true;
    if (frm.invalid) {
      return;
    }

    this.Auth.login(this.credentials).then(() => {
      if (this.returnUrl == '/'){
        window.location.href = '';
      }
      this.router.navigateByUrl(this.returnUrl)
    })
      .catch(() => {
        this.toasty.error(this.translate.instant('Your my-account is not activated or register. Please recheck again or contact to our admin to resolve it.'));
      });
  }
}
