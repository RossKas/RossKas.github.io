import { Component, OnInit, Input, OnChanges } from '@angular/core';
import { NgbModal, NgbModalOptions, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { ProductDetailModalComponent } from '../../../shared/modal/product-detail-modal/detail-modal.component';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { TranslateService } from '@ngx-translate/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ReviewService } from '../../../shared/services/review.service';
import { AuthService } from '../../../shared/services/auth.service';
import { SeoService } from '../../../shared/services/seo.service';
import { ProductVariantService } from '../../services/variant.service';
import { ShareButtons } from '@ngx-share/core';
import { WishlistService } from '../../../profile/services/wishlist.service';
import { ToastyService } from 'ng2-toasty';
import { CartService } from '../../../shared/services/cart.service';
import { ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import * as _ from 'lodash';

@Component({
  selector: 'product-card',
  templateUrl: './product-card.html',
  styleUrls: ['./product-card.component.css']
})
export class ProductCardComponent implements OnInit, OnChanges {
  @Input() product: any = {};
  @Input() showDeal: any = 0;
  @Input() viewType: any = '';
  public images: any = [];
  public isNoImage = false;
  public variantSpecs: any = [];
  public variants: any = [];
  public variantOptions: any = {};
  public isVariant = false;
  // public tab: any = 'detail';
  public selectedVariant: any = {};
  public selectedVariantValues: any = {};
  public page = 1;
  public quantity = 1;
  public stockQuantity = 0;
  public stockQuantityAlert = false;

  public price = 0;
  public salePrice = 0;
  public discountVal: any = 100;
  private modalReference: NgbModalRef;
  private closeResult: string;
  public activeSlide: any;
  public slidePosition = 0;
  public slideConfig: any = {
    'slidesToShow': 5,
    'slidesToScroll': 5,
    'vertical': true,
    'infinite': true,

  };
  public isModalOpened = false;
  public shopLink: any = '';

  constructor(private modalService: NgbModal,
    private translate: TranslateService, private router: Router,
    private route: ActivatedRoute, private reviewService: ReviewService,
    private authService: AuthService,
    private seoService: SeoService, private variantService: ProductVariantService, public share: ShareButtons,
    private wishlistService: WishlistService, private toasty: ToastyService, private cartService: CartService) {
    // this.setPrice();
  }

  gotoSeller() {
    this.modalReference.close();
    this.router.navigate([this.shopLink]);
  }

  ngOnInit() {

    this.shopLink = '/shops/' + this.product.shop.alias;
    this.setPrice();
    // this.activeSlide = this.product.images.length ? this.product.images[0] : '';
    // if (this.product.images.length) {
    //   this.product.images[0].isSlided = true;
    // }
  }
  ngOnChanges() {
    // this.setPrice();
  }

  // productReview() {
  //   let ngbModalOptions: NgbModalOptions = {
  //     backdrop: 'static',
  //     keyboard: false
  //   };
  //   this.modalService.open(ProductDetailModalComponent, ngbModalOptions);
  // }

  open(content) {
    // this.modalService.open(content);
    this.isModalOpened = true;
    this.modalReference = this.modalService.open(content);
    this.modalReference.result
      .then((result) => {
        this.isModalOpened = false;
      }).finally(() => {
        this.isModalOpened = false;
      });
    // this.modalReference.result.then((result) => {
    //   this.closeResult = `Closed with: ${result}`;
    // }, (reason) => {
    //   this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    this.getVariants();
  }
  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }

  changeQuantity(input) {
    this.quantity += (input);
    this.setPrice();
  }
  changeSlide(index: number) {
    this.slidePosition = index;
    this.activeSlide = this.images[index];
  }


  setPrice() {
    if (this.quantity > 0 && this.quantity <= this.product.stockQuantity) {
      this.price = this.product.price || 0;
      this.salePrice = this.quantity > 1 ? (this.product.price * this.quantity) : this.product.price;
      this.discountVal = this.product.price ? ((this.product.price - this.salePrice) / this.product.price * 100).toFixed(2) : '0';
      this.stockQuantity = this.product.stockQuantity;
      this.stockQuantityAlert = false;
    } else {
      this.quantity = 1;
      // this.toasty.error(this.translate.instant('Quantity is greater than stock quantity.'));
      this.stockQuantityAlert = true;
    }
  }

  getVariants() {
    this.variantService.search(this.product._id, { take: 100 }).then((resp) => {
      this.variants = resp;
      if (this.variants && this.variants.length) {
        this.variantSpecs = _.flatten(_.map(this.variants, 'variantOptions'));
        this.isVariant = true;
        for (let index = 0; index < this.variants.length; index++) {
          const element = this.variants[index];
          if (element.variantOptions) {
            const val = element.variantOptions.map(a => a.value).join('_') || '';
            this.variantOptions[val] = element;
          }
          if (index === 0) {
            element.variantOptions.forEach(e => {
              this.selectedVariantValues[e.option] = e.value;
            });
            this.selectVariant();
          }
        }
        this.setPrice();
      } else if (this.product.images && this.product.images.length) {
        this.images = this.product.images;
        this.activeSlide = this.product.images.length ? this.images[0] : '';
      } else {
        this.isNoImage = true;
      }
    });
  }

  filterVariantSpecs(specKey: string) {
    if (specKey) {
      return _.uniqBy(_.filter(this.variantSpecs, { option: specKey }), 'value');
    }
    return [];
  }

  // changeSlide(index: number) {
  //   this.slidePosition = index;
  //   this.activeSlide = this.product.images[index];
  // }

  selectVariant() {
    // console.log(this.selectedVariantValues);
    if (this.selectedVariantValues) {
      const variant = Object.values(this.selectedVariantValues).join('_');
      if (this.variantOptions[variant]) {
        this.isVariant = true;
        this.selectedVariant = this.variantOptions[variant];
        this.product.price = this.selectedVariant.price;
        this.product.stockQuantity = this.selectedVariant.stockQuantity;
        this.product.salePrice = this.selectedVariant.salePrice;
        this.setPrice();

        if (this.selectedVariant && this.selectedVariant.images && this.selectedVariant.images.length) {
          this.images = this.selectedVariant.images;
          this.activeSlide = this.selectedVariant.images[0];
        } else if (this.product.images && this.product.images.length) {
          this.images = this.product.images;
          this.activeSlide = this.product.images.length ? this.images[0] : '';
        } else {
          this.isNoImage = true;
        }
      } else {
        this.isVariant = false;
        this.product.stockQuantity = 0;
        this.toasty.error('This variant is not available.');
      }
    }
  }
  addWishList(item: any) {
    if (!this.authService.isLoggedin()) {
      return this.toasty.error(this.translate.instant('Please login before adding to wishlist.'));
    }
    this.wishlistService.create({ productId: item._id })
      .then(resp => this.toasty.success(this.translate.instant('Added to wishlist successfully.')));
  }

  addCart() {
    if (this.variants.length && !this.isVariant) {
      return this.toasty.error(this.translate.instant('Please select a variant option.'));
    }

    if (!this.product.stockQuantity) {
      return this.toasty.error(this.translate.instant('This item is out of stock.'));
    }
    if (this.quantity > this.product.stockQuantity) {
      return this.toasty.error(this.translate.instant('Available Stock Quantity is: ' + this.product.stockQuantity));
    }
    this.cartService.add({
      productId: this.product._id,
      productVariantId: this.isVariant ? this.selectedVariant._id : null,
      product: this.product
    }, this.quantity).then(result => {
      if (result) {
        this.router.navigate(['/cart/checkout']);
        this.modalReference.close();
      }
    });
  }
  buyNow() {
    if (this.variants.length && !this.isVariant) {
      return this.toasty.error(this.translate.instant('Please select a variant option.'));
    }

    if (!this.product.stockQuantity) {
      return this.toasty.error(this.translate.instant('This item is out of stock.'));
    }
    if (this.quantity > this.product.stockQuantity) {
      return this.toasty.error(this.translate.instant('Available Stock Quantity is: ' + this.product.stockQuantity));
    }
    this.cartService.add({
      productId: this.isVariant ? this.selectedVariant.productId : this.product._id,
      productVariantId: this.isVariant ? this.selectedVariant._id : null,
      product: this.product
    },
      this.quantity
    );
    this.router.navigate(['/cart/checkout']);
    this.modalReference.close();
  }

  viewProduct(alias: string): void {
    if (!this.isModalOpened && alias) {
      this.router.navigate(['/products', alias]);
    }
  }

}
