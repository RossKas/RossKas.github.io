import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { ProductModule } from '../product/product.module';
import { MediaModule } from '../media/media.module';
import { UtilsModule } from '../utils/utils.module';

import { ProfileRoutingModule } from './profile.routing';

import { ProfileSliderBarComponent } from './components/profile-sliderbar/sliderbar.component';
import { WishListComponent } from './components/wishlist/list.component';
import { UpdateComponent } from './components/update/update.component';
import { RefundListingComponent } from './components/refund/refund-listing.component';

import { WishlistService, RefundService } from './services';
import {MyAccountComponent} from './components/my-account/my-account.component';
import {NotificationComponent} from './components/notifications/notifications.component';
import {AddressesComponent} from './components/addresses/addresses';
import {PaymentOptionsComponent} from './components/payment-options/payment-options';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    NgbModule.forRoot(),
    ProfileRoutingModule,
    ProductModule,
    MediaModule,
    UtilsModule
  ],
  declarations: [
    WishListComponent,
    ProfileSliderBarComponent,
    UpdateComponent,
    RefundListingComponent,
    MyAccountComponent,
    NotificationComponent,
    AddressesComponent,
    PaymentOptionsComponent
  ],
  providers: [
    WishlistService,
    RefundService
  ],
  exports: [
    WishListComponent,
    ProfileSliderBarComponent,
    UpdateComponent
  ]
})
export class ProfileModule { }
