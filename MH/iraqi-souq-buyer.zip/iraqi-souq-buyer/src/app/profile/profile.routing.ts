import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { WishListComponent } from './components/wishlist/list.component';
import { UpdateComponent } from './components/update/update.component';
import { RefundListingComponent } from './components/refund/refund-listing.component';
import {MyAccountComponent} from './components/my-account/my-account.component';
import {NotificationComponent} from './components/notifications/notifications.component';
import {AddressesComponent} from './components/addresses/addresses';
import {PaymentOptionsComponent} from './components/payment-options/payment-options';

const routes: Routes = [
  {
    path: 'wishlist',
    component: WishListComponent
  },
  {
    path: 'my-account',
    component: MyAccountComponent
  },
  {
    path: 'update',
    component: UpdateComponent
  },
  {
    path: 'refunds',
    component: RefundListingComponent
  },
  {
    path: 'notifications',
    component: NotificationComponent
  },
  {
    path: 'addresses',
    component: AddressesComponent
  },
  {
    path: 'payment-options',
    component: PaymentOptionsComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ProfileRoutingModule { }
