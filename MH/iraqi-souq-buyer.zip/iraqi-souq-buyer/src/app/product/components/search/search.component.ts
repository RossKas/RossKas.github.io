import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { Location } from '@angular/common';
import { ToastyService } from 'ng2-toasty';
import { ProductService, CategoryService } from '../../services';
import { UtilService } from '../../../shared/services';
import * as _ from 'lodash';
import { BrandService } from '../../services';
@Component({
  selector: 'search-products',
  templateUrl: './search.html'
})
export class SearchComponent implements OnInit {
  public items: any = [];
  public filters: any = [];
  public page = 1;
  public itemsPerPage = 12;
  public searchFields: any = {
    q: '',
    categoryId: '',
    shopId: '',
    featured: '',
    hot: '',
    bestSell: '',
    dailyDeal: '',
    soldOut: '',
    discounted: ''
  };
  searchedProdCateId: '';
  public sort: any = '';
  public sortType: any = '';
  public total: any = 0;
  public noResults: any = false;
  public viewType = 'grid';
  public categoryBreadcrum: any;

  constructor(private toasty: ToastyService, private productService: ProductService, private route: ActivatedRoute,
    private router: Router,
    private utilService: UtilService, private _location: Location, private categoryService: CategoryService) {

  }

  ngOnInit() {
    this.defaultSearch();
  }

  goBack() {
    if (this.searchFields.checks) {
      this.defaultSearch();
    } else {
      this._location.back();
    }
  }
  // changeViewType(type) {
  //   this.viewType = type;
  // }
  defaultSearch() {

    this.route.queryParamMap.subscribe((params: Params) => {
      // console.log(params);
      this.searchFields = params.params;
      if (this.searchFields.categoryId) {
        this.loadBreadCrum(this.searchFields.categoryId);
      }
      this.query();
    });
  }

  loadBreadCrum(categoryId: string): void {
    this.categoryService.tree().then(resp => {
      this.categoryBreadcrum = this.categoryService.getBreadcrumbs(resp, categoryId);
      console.log(resp);
      console.log(this.categoryBreadcrum);
    });
  }

  query() {

    this.utilService.setLoading(true);
    const params = Object.assign({
      page: this.page,
      take: this.itemsPerPage,
      sort: this.sort,
      sortType: this.sortType
    }, this.searchFields, this.searchFields.checks ? { specs: { ...this.searchFields.checks } } : {},
      this.searchFields.brands ? { brands: { ...this.searchFields.brands } } : {});
    // console.log(params);
    this.productService.search(params).then((res) => {
      // console.log(res);
      this.noResults = res.data.items.length > 0 ? false : true;
      this.items = res.data.items;
      this.filters = res.data.filters;
      this.total = res.data.count;
      this.utilService.setLoading(false);

      if (this.searchFields.q) {
        if (this.items) {
          this.searchedProdCateId = this.items[0].categoryId;
        }
      }

    })
      .catch(() => {
        this.noResults = true;
        this.utilService.setLoading(false);
      });
  }

  changeSort(sort: string, $event: any) {
    this.sort = sort;
    this.sortType = $event.target.value;
    this.page = 1;
    this.query();
  }

  updateFields(event: any) {
    this.searchFields = Object.assign(event, this.searchFields);
    this.query();
  }

  selectCategory(category: any) {
    this.router.navigate(['/products/search'], {
      queryParams: { categoryId: category.id }
    });
  }
}
