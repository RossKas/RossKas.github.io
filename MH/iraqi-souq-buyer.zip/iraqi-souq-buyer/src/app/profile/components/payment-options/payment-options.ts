import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { ToastyService } from 'ng2-toasty';
// import { StaticPageService } from '../services/static-page.service';
import { TranslateService } from '@ngx-translate/core';
import {StaticPageService} from '../../../static-page/services/static-page.service';

@Component({
  selector: 'payment-options',
  templateUrl: './payment-options.html',
  styleUrls: ['./payment-options.css']
})
export class PaymentOptionsComponent implements OnInit {
  public page: any = {};

  constructor(private router: Router, private route: ActivatedRoute) {
  }

  ngOnInit() {
  }
}
