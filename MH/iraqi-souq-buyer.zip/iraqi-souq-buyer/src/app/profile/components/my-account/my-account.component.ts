import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { ToastyService } from 'ng2-toasty';
// import { StaticPageService } from '../services/static-page.service';
import { TranslateService } from '@ngx-translate/core';
import {StaticPageService} from '../../../static-page/services/static-page.service';
import {AuthService} from '../../../shared/services/auth.service';
@Component({
  selector: 'my-account',
  templateUrl: './my-account.html',
  styleUrls: ['./my-account.css']
})
export class MyAccountComponent implements OnInit {
  public page: any = {};
  public appConfig: any;
  public currentUser: any;
  public userEmail: any;
  constructor(private router: Router, private route: ActivatedRoute, private authService: AuthService) {
    this.appConfig = window.appConfig;
  }

  ngOnInit() {
    if (this.authService.isLoggedin()) {
      this.authService.getCurrentUser().then(resp => {
        this.currentUser = resp;
        this.userEmail = this.currentUser.email;
      });
    }
  }
}
