import { Component, OnInit, Input } from '@angular/core';
import { BannerService } from './service';
import {Router} from '@angular/router';

@Component({
  selector: 'app-banner',
  templateUrl: './banner.html',
  styleUrls: ['./banner.component.css']
})
export class BannerComponent implements OnInit {
  @Input() position: any = 'default';
  public bannerStyle: any = {};
  public banners: any = [];

  public slideConfig: any = {
    slidesToShow: 1,
    slidesToScroll: 1,
    dots: true,
    arrows: true,
    autoplay: true,
    autoplaySpeed: 2000
  };

  constructor(private service: BannerService, private router: Router) {
  }

  ngOnInit() {
    this.service.random({
      take: 5,
      position: this.position
    })
      .then(resp => {
        if (resp.data.length) {
          this.banners = resp.data.map(item => {
            return {
              imageUrl: item.media ? item.media.fileUrl : '/assets/images/banner.jpg',
              link: item.link ? item.link : '#'
            };
          });
        } else {
          this.banners = [{
            imageUrl: '/assets/images/banner.jpg'
          }];
        }
      });
  }

  goPhones() {
    this.router.navigate(['/products/search'], {
      queryParams: { categoryId: '5ce4b3ed8f752c46ae99b615'}
    });
  }
  goFashion() {
    this.router.navigate(['/products/search'], {
      queryParams: { categoryId: '5ce4b3ed8f752c46ae99b624'}
    });
  }
  goFurniture() {
    this.router.navigate(['/products/search'], {
      queryParams: { categoryId: '5ce4b3f58f752c46ae99b83b'}
    });
  }
  goKids() {
    this.router.navigate(['/products/search'], {
      queryParams: { categoryId: '5ce4b3f18f752c46ae99b6f7'}
    });
  }
  goToys() {
    this.router.navigate(['/products/search'], {
      queryParams: { categoryId: '5ce4b3fa8f752c46ae99b9de'}
    });
  }
}
