import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import {NgbModalModule, NgbModule} from '@ng-bootstrap/ng-bootstrap';
import { ProductRoutingModule } from './product.routing';
import { CartModule } from '../cart/cart.module';
import { ShareModule } from '@ngx-share/core';

import {MatExpansionModule} from '@angular/material/expansion';

import { NgxImageZoomModule } from 'ngx-image-zoom';
import { SlickCarouselModule } from 'ngx-slick-carousel';

import { ProductDetailComponent } from './components/detail/detail.component';
import { ProductCardComponent } from './components/product-card/product-card.component';
import { FeaturedProductsComponent } from './components/featured-products/featured-products.component';
import { SearchComponent } from './components/search/search.component';
import { SearchSidebarComponent } from './components/search-sidebar/search-sidebar.component';

import { BrandService, CategoryService, ProductService, ProductVariantService } from './services';
import { ReviewService } from '../shared/services';
import { WishlistService } from '../profile/services';

import { ProductResolver } from './resolvers/product.resolver';
import { SearchResolver } from './resolvers/search.resolver';
import { CurrencyPipe } from '../shared/pipes';
import { SafePipe } from '../shared/pipes';

import { UtilsModule } from '../utils/utils.module';
import { MessageModule } from '../message/message.module';

import { MatTabsModule, MatStepperModule} from '@angular/material';
import {ProductDetailModalComponent} from '../shared/modal/product-detail-modal/detail-modal.component';
import {ModalModule} from '../shared/modal/modal.module';
import { ProductCategoriesComponent } from './components/product-categories/product-categories.component';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ProductRoutingModule,
    NgbModule.forRoot(),
    NgxImageZoomModule.forRoot(),
    ShareModule.forRoot(),
    CartModule,
    // ModalModule,
    UtilsModule,
    SlickCarouselModule,
    MessageModule,
    MatTabsModule,
    MatExpansionModule,
    NgbModalModule
  ],
  declarations: [
    ProductDetailComponent,
    // ProductDetailModalComponent,
    FeaturedProductsComponent,
    ProductCardComponent,
    SearchSidebarComponent,
    SearchComponent,
    ProductCategoriesComponent,
    CurrencyPipe,
    SafePipe
  ],
  providers: [
    BrandService,
    CategoryService,
    ProductService,
    ProductResolver,
    SearchResolver,
    ProductVariantService,
    ReviewService,
    WishlistService
  ],
  // entryComponents: [
  //   ProductDetailModalComponent
  // ],
  exports: [
    FeaturedProductsComponent,
    ProductCardComponent,
    SearchSidebarComponent,
    SearchComponent
  ]
})
export class ProductModule { }
