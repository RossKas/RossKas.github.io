import { Component, OnInit, OnDestroy, Input } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { SeoService, ReviewService, CartService, AuthService } from '../../../shared/services';
import { ProductVariantService } from '../../services';
import { WishlistService } from '../../../profile/services';
import { ToastyService } from 'ng2-toasty';
import { TranslateService } from '@ngx-translate/core';
import * as _ from 'lodash';
import { ShareButtons } from '@ngx-share/core';
import { Subscription } from 'rxjs/Subscription';
import * as $ from 'jquery';

@Component({
  templateUrl: './detail.html',
  styleUrls: ['./detail.css']
})
export class ProductDetailComponent implements OnInit, OnDestroy {
  public cart: any = {};
  public productId: any;
  public product: any;
  public images: any = [];
  public isNoImage = false;
  public discount: any = 100;
  public discountVal: any = 100;
  public variants: any = [];
  public variantSpecs: any = [];
  public isVariant = false;
  public tab: any = 'detail';
  public selectedVariant: any = {};
  public selectedVariantValues: any = {};
  public page = 1;
  public quantity = 1;
  public activeSlide: any;
  public slidePosition = 0;
  private productSubscription: Subscription;
  public slideConfig: any = {
    'slidesToShow': 5,
    'slidesToScroll': 5,
    'vertical': true,
    'infinite': true,

  };
  public isRed: any = 'red';
  public price = 0;
  public salePrice = 0;
  public stockQuantity = 0;
  public variantOptions: any = [];
  public shopLink: any = '';
  constructor(private translate: TranslateService,
    private router: Router,
    private route: ActivatedRoute, private reviewService: ReviewService, private authService: AuthService,
    private seoService: SeoService, private variantService: ProductVariantService, public share: ShareButtons,
    private wishlistService: WishlistService, private toasty: ToastyService, private cartService: CartService) {

  }

  ngOnInit() {
    this.product = this.route.snapshot.data.product;
    this.productSubscription = this.route.data.subscribe(data => {
      this.product = data.product;
      console.log('product', this.product);

      this.shopLink = '/shops/' + this.product.shop.alias;
      this.seoService.update(this.product.name, this.product.metaSeo);
      // this.activeSlide = data.product.images.length ? data.product.images[0] : '';
      // if (this.product.images.length) {
      //   this.product.images[0].isSlided = true;
      // }
      this.getVariants();
      this.setPrice();
    });
  }

  ngOnDestroy() {
    this.productSubscription.unsubscribe();
  }

  changeQuantity(input) {
    this.quantity += (input);
    this.setPrice();
  }

  setPrice() {
    if (this.quantity > 0 && this.quantity <= this.product.stockQuantity) {
      this.price = this.product.price || 0;
      this.salePrice = this.quantity > 1 ? (this.product.price * this.quantity) : this.product.price;
      this.discountVal = this.product.price ? ((this.product.price - this.salePrice) / this.product.price * 100).toFixed(2) : '0';
      this.stockQuantity = this.product.stockQuantity;
    } else {
      this.quantity = 1;
      this.toasty.error(this.translate.instant('Quantity is greater than stock quantity.'));
    }
  }

  getVariants() {
    this.variantService.search(this.product._id, { take: 100 }).then((resp) => {
      this.variants = resp;
      // console.log('variants: ', this.variants);
      // console.log(_.flatten(_.map(this.variants, 'variantOptions')));
      if (this.variants && this.variants.length) {
        this.variantSpecs = _.flatten(_.map(this.variants, 'variantOptions'));
        this.isVariant = true;
        for (let index = 0; index < this.variants.length; index++) {
          const element = this.variants[index];
          if (element.variantOptions) {
            const val = element.variantOptions.map(a => a.value).join('_') || '';
            this.variantOptions[val] = element;
          }
          if (index === 0) {
            element.variantOptions.forEach(e => {
              this.selectedVariantValues[e.option] = e.value;
            });
            this.selectVariant();
          }
        }
        this.setPrice();
      } else if (this.product.images && this.product.images.length) {
        this.images = this.product.images;
        this.activeSlide = this.product.images.length ? this.images[0] : '';
      } else {
        this.isNoImage = true;
      }
    });
  }

  filterVariantSpecs(specKey: string) {
    if (specKey) {
      return _.uniqBy(_.filter(this.variantSpecs, { option: specKey }), 'value');
    }
    return [];
  }

  groupBy(list, keyGetter) {
    const map = new Map();
    list.forEach((item) => {
      const key = keyGetter(item);
      const collection = map.get(key);
      if (!collection) {
        map.set(key, [item]);
      } else {
        collection.push(item);
      }
    });
    return map;
  }

  changeSlide(index: number) {
    this.slidePosition = index;
    this.activeSlide = this.images[index];
  }

  selectVariant() {
    // console.log(this.selectedVariantValues);
    if (this.selectedVariantValues) {
      const variant = Object.values(this.selectedVariantValues).join('_');
      if (this.variantOptions[variant]) {
        this.isVariant = true;
        this.selectedVariant = this.variantOptions[variant];
        this.product.price = this.selectedVariant.price;
        this.product.stockQuantity = this.selectedVariant.stockQuantity;
        this.product.salePrice = this.selectedVariant.salePrice;
        this.setPrice();

        if (this.selectedVariant && this.selectedVariant.images && this.selectedVariant.images.length) {
          console.log(this.selectedVariant);
          this.images = this.selectedVariant.images;
          this.activeSlide = this.selectedVariant.images[0];
        } else if (this.product.images && this.product.images.length) {
          this.images = this.product.images;
          this.activeSlide = this.product.images.length ? this.images[0] : '';
        } else {
          this.isNoImage = true;
        }
      } else {
        this.isVariant = false;
        this.product.stockQuantity = 0;
        this.toasty.error('This variant is not available.');
      }
    }
  }

  // helper function to compare arrays.
  isEqual(value, other) {
    const this_ = this;
    // Get the value type
    const type = Object.prototype.toString.call(value);

    // If the two objects are not the same type, return false
    if (type !== Object.prototype.toString.call(other)) return false;

    // If items are not an object or array, return false
    if (['[object Array]', '[object Object]'].indexOf(type) < 0) return false;

    // Compare the length of the length of the two items
    const valueLen = type === '[object Array]' ? value.length : Object.keys(value).length;
    const otherLen = type === '[object Array]' ? other.length : Object.keys(other).length;
    if (valueLen !== otherLen) return false;

    // Compare two items
    const compare = function (item1, item2) {

      // Get the object type
      const itemType = Object.prototype.toString.call(item1);

      // If an object or array, compare recursively
      if (['[object Array]', '[object Object]'].indexOf(itemType) >= 0) {
        if (!this_.isEqual(item1, item2)) return false;
      }

      // Otherwise, do a simple comparison
      else {

        // If the two items are not the same type, return false
        if (itemType !== Object.prototype.toString.call(item2)) return false;

        // Else if it's a function, convert to a string and compare
        // Otherwise, just compare
        if (itemType === '[object Function]') {
          if (item1.toString() !== item2.toString()) return false;
        } else {
          if (item1 !== item2) return false;
        }

      }
    };

    // Compare properties
    if (type === '[object Array]') {
      for (let i = 0; i < valueLen; i++) {
        if (compare(value[i], other[i]) === false) return false;
      }
    } else {
      for (const key in value) {
        if (value.hasOwnProperty(key)) {
          if (compare(value[key], other[key]) === false) return false;
        }
      }
    }

    // If nothing failed, return true
    return true;

  }

  addWishList(item: any) {
    if (!this.authService.isLoggedin()) {
      return this.toasty.error(this.translate.instant('Please login before adding to wishlist.'));
    }
    this.wishlistService.create({ productId: item._id })
      .then(resp => this.toasty.success(this.translate.instant('Added to wishlist successfully.')));
  }

  addCart() {
    if (this.variants.length && !this.isVariant) {
      return this.toasty.error(this.translate.instant('Please select a variant option.'));
    }

    if (!this.stockQuantity) {
      return this.toasty.error(this.translate.instant('This item is out of stock.'));
    }
    if (this.quantity > this.stockQuantity) {
      return this.toasty.error(this.translate.instant('Available Stock Quantity is: ' + this.stockQuantity));
    }

    console.log('add to cart: ', this.selectedVariant);
    this.cartService.add({
      productId: this.isVariant ? this.selectedVariant.productId : this.product._id,
      productVariantId: this.isVariant ? this.selectedVariant._id : null,
      product: this.product
    }, this.quantity).then(result => {
      if (result) {
        this.router.navigate(['/cart/checkout']);
      }
    });
  }

  buyNow() {
    if (this.variants.length && !this.isVariant) {
      return this.toasty.error(this.translate.instant('Please select a variant option.'));
    }

    if (!this.stockQuantity) {
      return this.toasty.error(this.translate.instant('This item is out of stock.'));
    }
    if (this.quantity > this.stockQuantity) {
      return this.toasty.error(this.translate.instant('Available Stock Quantity is: ' + this.stockQuantity));
    }
    const result = this.cartService.add({
      productId: this.isVariant ? this.selectedVariant.productId : this.product._id,
      productVariantId: this.isVariant ? this.selectedVariant._id : null,
      product: this.product
    }, this.quantity);

    if (result) {
      this.router.navigate(['/cart/checkout']);
    }
  }

  goToLink(url: string) {
    window.open(url, '_blank');
  }


}
