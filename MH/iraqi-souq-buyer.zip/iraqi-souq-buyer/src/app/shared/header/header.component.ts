import { Component, OnInit, OnDestroy, Input, Output, EventEmitter, OnChanges, AfterViewInit } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { Subscription } from 'rxjs/Subscription';
import { AuthService, SystemService } from '../services';
import { NgbModal, NgbModalOptions } from '@ng-bootstrap/ng-bootstrap';
import { ComplainComponent } from '../complain/complain.component';
import { CategoryService } from '../../product/services';
import { CartService } from '../services/cart.service';
import { environment } from '../../../environments/environment';
import { ProductService } from '../../product/services/product.service';
import { UtilService } from '../services/utils.service';
import { MatMenuModule } from '@angular/material';
import { TranslateService } from '@ngx-translate/core';
import { catchError, debounceTime, distinctUntilChanged, map, tap, switchMap } from 'rxjs/operators';
import { Observable, of } from 'rxjs';
import { trigger, state, style, transition, animate } from '@angular/animations';


@Component({
  selector: 'app-header',
  templateUrl: './header.html',
  styleUrls: ['./header.component.css'],
  animations: [
    trigger('SubMenu', [
      state('open', style({
        transform: 'translateX(0px)'
      })),
      state('close', style({
        transform: 'translateX(-100px)'
      })),
      transition('close <=> open', animate('300ms ease-in'))
    ])
  ]
})
export class HeaderComponent implements OnInit, OnDestroy, OnChanges {
  @Output() toggled = new EventEmitter();
  @Input() click: any;
  @Input() options: any = {};
  public simpleItems = [{ id: 1, name: 'English' }, { id: 2, name: 'Arabic' }];
  public currencyItems = [{ id: 1, name: 'USD', value: 'US' }, { id: 2, name: 'IQD', value: 'IQ' }];
  public selectedCurrency: any = '';
  public selectedLanguage: any = 'English';
  public selectedCat: any;
  public q: any;
  public currentUser: any;
  public isShowed = false;
  private userLoadedSubscription: Subscription;
  public appConfig: any = {};
  public languages: any = [];
  public userLang = 'en';
  public userCurrency = 'USD';
  public userEmail: any;

  public tree: any = [];
  private cartLoadedSubscription: Subscription;
  public cart: any = [];
  public shopLink = environment.sellerUrl;
  public items: any = [];
  public filters: any = [];
  public page = 1;
  public itemsPerPage = 12;
  public sort: any = '';
  public sortType: any = '';
  public total: any = 0;

  public firstNameSplit: any;
  public firstName: any;
  public selectedValue: any;
  private language: any;

  public selectedOption = 'Select Categories';
  public selectedCategory: any;
  public isClickCategory = false;

  public state = 'close';

  // public isUpdate: boolean = true;


  public searching = false;
  public searchFailed = false;

  formatter = (x: { name: string }) => x.name;
  search = (text$: Observable<string>) =>
    text$.pipe(
      debounceTime(300),
      distinctUntilChanged(),
      tap(() => {
        this.searching = true;
      }),
      switchMap(term =>
        this.productService.search({ q: term }).then((res) => {
          if (res) {
            this.searchFailed = false;
            this.searching = false;
            return res.data.items;
            // const val = res.data.items;
          }
          this.searchFailed = true;
          this.searching = false;
          return of([]);
          // return this.q;
        })
      )
    )


  // header sidebar functionality
  private _opened = false;
  private _modeNum = 0;
  private _positionNum = 0;
  private _dock = false;
  private _closeOnClickOutside = false;
  private _closeOnClickBackdrop = false;
  private _showBackdrop = false;
  private _animate = true;
  private _trapFocus = true;
  private _autoFocus = true;
  private _keyClose = false;
  private _autoCollapseHeight: number = null;
  private _autoCollapseWidth: number = null;

  private _MODES: Array<string> = ['push', 'over', 'slide'];
  private _POSITIONS: Array<string> = ['left', 'right', 'top', 'bottom'];

  public queryParameters = {
    q: this.q,
    selectedCategory: this.selectedCategory
  };
  private categoryName: any = [];

  constructor(private authService: AuthService, private router: Router, private route: ActivatedRoute,
    private systemService: SystemService, private modalService: NgbModal, private categoryService: CategoryService,
    private cartService: CartService,
    private productService: ProductService,
    private utilService: UtilService,
    private translate: TranslateService) {
    this.appConfig = window.appConfig;
    this.userLoadedSubscription = authService.userLoaded$.subscribe(data => this.currentUser = data);
    systemService.configs().then(resp => {
      // this.appConfig = resp;
      this.languages = resp.i18n.languages;
      this.userLang = resp.userLang;
    });

    this.userCurrency = localStorage.getItem('userCurrency') ? localStorage.getItem('userCurrency') : 'US';
    this.cartLoadedSubscription = cartService.cartChanged$.subscribe(data => this.cart = data);
    // console.log(this.currentUser);
  }

  ngOnInit() {
    if (this.authService.isLoggedin()) {
      this.authService.getCurrentUser().then(resp => {
        this.currentUser = resp;
        this.userEmail = this.currentUser.email;
        this.firstNameSplit = this.currentUser.name.split(' ');
        this.firstName = this.firstNameSplit[0];
      });
    }
    this.categoryService.tree()
      .then(resp => {

        this.tree = resp;
        let child = [];
        let count = 0;
        for (let i = 0; i < this.tree.length; i++) {
          if (this.tree[i].children) {
            if (this.tree[i].children.length) {
              for (let j = 0; j < this.tree[i].children.length; j++) {
                if (this.tree[i].children[j].children) {
                  if (this.tree[i].children[j].children.length) {
                    for (let k = 0; k < this.tree[i].children[j].children.length; k++) {
                      count++;
                      if (count <= 5) {
                        child.push(this.tree[i].children[j].children[k])
                      }
                    }
                    this.tree[i].children[j].children = child;
                    child = []
                    count = 0
                  }
                }
              }
            }
          }
        }


        this.renderMenu(resp);
      });
    //  cart service below //
    this.cart = this.cartService.get();
  }
  ngOnChanges() {

    if (this.simpleItems[0].id) {
      this.language = 'en';
      // const defaultLang = 'en';
      // https://github.com/ngx-translate/core
      this.translate.setDefaultLang(this.language);
      this.systemService.configs().then(resp => {
        this.translate.setDefaultLang(resp.i18n.defaultLanguage);
        this.translate.use(resp.userLang);
      });
    } else {
      this.language = 'es';
      this.translate.setDefaultLang(this.language);
      this.systemService.configs().then(resp => {
        this.translate.setDefaultLang(resp.i18n.defaultLanguage);
        this.translate.use(resp.userLang);
      });
    }


  }
  // gotoShop() {
  //   this.router.navigate([this.shopLink,'/auth/signup']);
  //   this.router.navigate(['/auth/signup']);
  // }
  toggleSidebar() {
    this.toggled.emit();
  }

  renderMenu(tree: any[]) {
    this.items = [];
    
    if (tree) {
      const menuLength = tree.length; // > 8 ? 8 : tree.length;
      for (let index = 0; index < menuLength; index++) {
        const element = tree[index];
        
        if (element.children) {
          const item = {
            label: element.name, items: [],
            routerLink: ['/products/search'], queryParams: { categoryId: element._id }
          };
        
          const tempItems = [];
        
          element.children.forEach(child => {
            const childItem = {
              label: child.name, items: [],
              routerLink: ['/products/search'], queryParams: { categoryId: child._id }
            };
        
            if (child.children) {
              child.children.forEach(subChild => {
                childItem.items.push({
                  label: subChild.name,
                  routerLink: ['/products/search'], queryParams: { categoryId: subChild._id }
                });
              });
            }
            tempItems.push(childItem);
          });
        
          if (tempItems.length > 4) {
            let i, j, temparray;
            const chunk = 2;
            for (i = 0, j = tempItems.length; i < j; i += chunk) {
              temparray = tempItems.slice(i, i + chunk);
              item.items.push(temparray);
            }
          } else {
            item.items.push(tempItems);
          }
        
          this.items.push(item);
        } else {
          const item = {
            label: element.name,
            routerLink: ['/products/search'], queryParams: { categoryId: element._id }
          };
          this.items.push(item);
        }
      }
    }
  }

  searchCat(item: any) {
    // nativate to search page

    this.router.navigate(['/products/search'], {
      queryParams: { categoryId: item._id }
    });

    this.isClickCategory = true;
  }

  hotItems() {
    this.router.navigate(['/products/search'], {
      queryParams: { hot: '1' }
    });
  }

  featuredItems() {
    this.router.navigate(['/products/search'], {
      queryParams: { featured: '1' }
    });
  }

  ngOnDestroy() {
    // prevent memory leak when component destroyed
    this.userLoadedSubscription.unsubscribe();
  }

  logout() {
    this.authService.removeToken();
    // this.router.navigate(['/auth/login']);
    window.location.href = '/';
  }

  dropdown() {
    this.isShowed = !this.isShowed;
  }

  keyPress(event: any) {
    if (event.charCode === 13) {
      this.searchProd();
    }
  }

  searchProd() {
    if (!this.q.trim()) {
      return;
    }

    // nativate to search page
    this.router.navigate(['/products/search'], {
      queryParams: { q: this.q, categoryId: this.selectedCategory }
    });
  }

  onSubmit(name: any) {
    if (name) {
      this.router.navigate(['/products/search'], {
        queryParams: { q: name, categoryId: this.selectedCategory }
      });
    } else {
      this.router.navigate(['/products/search'], {
        queryParams: { q: this.q.name ? this.q.name : this.q, categoryId: this.selectedCategory }
      });
    }
  }

  complain() {
    const ngbModalOptions: NgbModalOptions = {
      backdrop: 'static',
      keyboard: false
    };
    this.modalService.open(ComplainComponent, ngbModalOptions);
  }

  // search(item:any) {
  //   // nativate to search page
  //   this.router.navigate(['/products/search'], {
  //     queryParams: { categoryId: item._id }
  //   });
  // }

  private _toggleOpened(): void {
    this._opened = !this._opened;
  }

  onChange(event) {
    this.selectedCategory = event;
    // console.log('Value is: ', this.selectedCategory);
  }

  changeLang(item: any) {
    this.systemService.setUserLang(item.key);
    this.translate.use(item.key);
    this.userLang = item.key;
  }

  changeCurrency(item: any) {
    this.systemService.setUserCurrency(item.value);
    this.userCurrency = item.value;
    window.location.href = window.location.href;
  }

  featuredQuery() {
    const params = Object.assign({
      page: this.page,
      take: this.itemsPerPage,
      sort: this.sort,
      sortType: this.sortType
    }, this.options);

    this.productService.search(params).then((res) => {
      this.items = res.data.items;
    });
  }

  animate() {
    this.state = this.state === 'close' ? 'open' : 'close';
  }

  removeActiveClass() {
    if (this.state === 'close') {
      // console.log('Hover-Out');
      $('#home > div.sub-menu-1.home > table > tbody > tr > td.home-menu.border-radius-bl > ul > li.is-active').removeClass('is-active');
    }
    return true;
  }

}
