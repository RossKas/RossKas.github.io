import { Pusher } from 'pusher-js';
import {Component, OnInit, OnChanges , ViewChild, ElementRef, Input, AfterViewInit} from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { CartService } from '../../../shared/services';
import { ToastyService } from 'ng2-toasty';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { CodVerifyModalComponent } from '../cod-verify-modal/cod-verify-modal.component';
import { OrderService } from '../../../order/services/order.service';
import { TransactionService } from '../../services/transaction.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { StripeService, ElementsOptions, StripeCardComponent, Elements, Element as StripeElement, } from 'ngx-stripe';
import { TranslateService } from '@ngx-translate/core';
import * as _ from 'lodash';
import {ProductService} from '../../../product/services/product.service';
import { FeaturedProductsComponent} from '../../../product/components/featured-products/featured-products.component';
import { NO_ERRORS_SCHEMA} from '@angular/core';
import { MatTabChangeEvent} from '@angular/material';
import index from "@angular/cli/lib/cli";
import {AuthService} from '../../../shared/services/auth.service';
import {Subscription} from "rxjs/Rx";
// import { }

@Component({
  templateUrl: './checkout-detail.html',
  styleUrls: ['./../cart.css']
})
export class CheckoutDetailComponent implements OnInit, OnChanges, AfterViewInit {
  @Input() options: any = {};

  isLinear = false;
  firstFormGroup: FormGroup;
  secondFormGroup: FormGroup;

  isShipping: false;
  isOrder = false;
  // event: MatTabChangeEvent;

  public isSpinnerVisible = true;
  private loadingSubscription: Subscription;

  public savedAddress: any = [];

  public cart: any = [];
  public totalPrice: any = 0;
  public totalTaxPrice: any = 0;
  public totalShippingPrice: any = 0;
  public userInfo: any = {
    paymentMethod: 'stripe'
  };
  public phoneNumber: any;
  public isSubmitted: any = false;
  public dialCode: any = '';
  public codCode: any = '';
  public orderId: any;

  public items: any = [];
  public page: any = 1;
  public itemsPerPage: any = 8;
  public searchFields: any = {};

  public orders = [];
  public lastOrder: any = {};
  public checkoutResponse: any = {};
  public take: Number = 10;
  public total: Number = 0;
  public searchField: any = {
    status: ''
  };

  public sortOption = {
    sortBy: 'createdAt',
    sortType: 'desc'
  };

  public sort: any = 'random';
  public sortType: any = '';
  public selectedTab = 0;
  public cardNumber: any;
  public expiryMonth: any;
  public expiryYear: any;
  public cvc: any;

  @ViewChild(StripeCardComponent) card: StripeCardComponent;
  public cardHolderName: any = '';
  public cardOptions: any = {};
  // optional parameters
  public elementsOptions: ElementsOptions = {
    locale: 'en'
  };

  public stripeTest: FormGroup;
  public stripeToken: any = null;
  selectedIndex: any[];
  public userAllAddress: any[];

  constructor(private translate: TranslateService, private router: Router, private route: ActivatedRoute, private cartService: CartService,
    private orderService: OrderService, private transactionService: TransactionService,
    private toasty: ToastyService, private modalService: NgbModal,
    private fb: FormBuilder,
    private stripeService: StripeService,
    private productService: ProductService,
    private auth: AuthService) {
    const config = this.route.snapshot.data['appConfig'];
    this.userInfo.userCurrency = config ? config.customerCurrency : 'USD';

}

  ngOnInit() {
    // this.userAddresses();
    //
    // const cartData = localStorage.getItem('cart');
    // this.cart = cartData ? JSON.parse(cartData) : [];



    // console.log('service: ',this.cartService.get());

     this.cart = this.route.snapshot.data.cart;
     this.updateTotalPrice();
     this.query();
    // console.log('cart: ',this.cart);

    this.stripeService.setKey(window.appConfig.stripeKey);
    this.stripeTest = this.fb.group({
      cardName: ['', [Validators.required]]
    });
    // this.order();

  }

  fill(address: any) {
    this.userInfo.streetAddress = address.streetNo;
    this.userInfo.city = address.city;
    this.userInfo.state = address.state;
    this.userInfo.country = address.country;
  }

  changeTab() {

    this.selectedTab += 1;
    if (this.selectedTab >= 3) this.selectedTab = 0;

  }

  ngOnChanges() {
    this.query();
  }

  ngAfterViewInit() {
    // this.userAddresses();
    // this.selectedIndex = this.selectedIndex;
    // this.onLinkClick(this.event);
  }

  saveAddress() {
    this.auth.createAddress({
      name: this.userInfo.firstName + ' ' + this.userInfo.lastName,
      streetNo: this.userInfo.streetAddress,
      city: this.userInfo.city,
      state: this.userInfo.state,
      country: this.userInfo.country
    })
      .then((resp) => {
      this.savedAddress = resp;
      console.log(this.savedAddress);
      });
  }

  remove(index: number) {
    this.cartService.remove(this.cart.products[index]);
    this.cart.products.splice(index, 1);
    this.updateTotalPrice();
  }

  getToken() {

    if (this.userInfo.paymentMethod === 'cod') {
      this.userInfo.phoneVerifyCode = '123';
      this.doPost();
      // const phoneNumber = `${this.dialCode}${this.phoneNumber}`;
      // this.orderService.checkPhone(phoneNumber)
      //   .then(resp => {
      //     const modalRef = this.modalService.open(CodVerifyModalComponent, {
      //       backdrop: 'static',
      //       keyboard: false
      //     });
      //     modalRef.result.then(result => {
      //       this.userInfo.phoneVerifyCode = result.verifyCode;
      //       this.doPost();
      //     }, () => { });
      //   })
      //   .catch((err) => this.toasty.error(this.translate.instant('An error occurred, please recheck your phone number!')));
    }else if (this.userInfo.paymentMethod === 'stripe') {
    (<any>window).Stripe.card.createToken({
      number: this.cardNumber,
      exp_month: this.expiryMonth,
      exp_year: this.expiryYear,
      cvc: this.cvc
    }, (status: number, response: any) => {
      if (status === 200) {
        this.stripeToken = response.id;
        this.doPost();
      } else {
        console.log(response.error.message);
      }
    });
  }
  }

  updateTotalPrice() {
    this.totalPrice = 0;
    this.totalTaxPrice = 0;
    this.totalShippingPrice = 0;

    if (!this.cart.products.length) {
      return;
    }

    this.cart.products.forEach((product) => {
      if (product.quantity < 1) {
        product.quantity = 1;
      }
      product.calculatedData = {
        product: product.userProductPrice * product.quantity,
        taxClass: product.taxClass,
        tax: 0,
        shipping: 0
      };
      if (product.taxPercentage && product.taxClass) {
        product.calculatedData.taxClass = product.taxClass;
        product.calculatedData.tax = product.calculatedData.product * (product.taxPercentage / 100);
        this.totalTaxPrice += product.calculatedData.tax;
      }
      if (!product.freeShip && product.storeWideShipping) {
        let shipping = product.shippingSettings.defaultPrice;
        if (product.quantity > 1) {
          shipping += product.shippingSettings.perQuantityPrice * (product.quantity - 1);
        }
        product.calculatedData.shipping = shipping;
        this.totalShippingPrice += product.calculatedData.shipping;
      }

      product.calculatedData.total = product.calculatedData.product + product.calculatedData.tax + product.calculatedData.shipping;

      this.totalPrice += product.calculatedData.total;
    });
  }

  submit(frm: any) {
    this.isSubmitted = true;
    if (frm.invalid) {
      return this.toasty.error(this.translate.instant('Please submit valid form'));
    }

    let error = false;
    if (!this.cart.products || !this.cart.products.length) {
      return this.toasty.error(this.translate.instant('Please add product to your cart!'));
    }
    this.cart.products.forEach((cart) => {
      if (cart.error) {
        error = true;
        return this.toasty.error(`${cart.product.name}` + this.translate.instant(' is out of stock'));
      }

      if (cart.quantity > cart.stockQuantity) {
        error = true;
        return this.toasty.error(`${cart.product.name}` + this.translate.instant(' just has ') +
          `${cart.stockQuantity}` + this.translate.instant(' in the stock'));
      }

      if (this.userInfo.paymentMethod === 'cod') {
        const areas = cart.product.restrictCODAreas;
        const index = _.findIndex(areas, (a) => a.toString().trim().toLowerCase() === this.userInfo.zipCode.trim().toLowerCase());
        if (index > -1) {
          error = true;
          return this.toasty.error(`${this.userInfo.zipCode}` + this.translate.instant(' is not been supported for shipping.'));
        }
      }
    });

    if (error) {
      return;
    }


    if (this.userInfo.paymentMethod === 'cod') {
      console.log('cod')
      this.doPost();
      // const phoneNumber = `${this.dialCode}${this.phoneNumber}`;
      // this.orderService.checkPhone(phoneNumber)
      //   .then(resp => {
      //     const modalRef = this.modalService.open(CodVerifyModalComponent, {
      //       backdrop: 'static',
      //       keyboard: false
      //     });
      //     modalRef.result.then(result => {
      //       this.userInfo.phoneVerifyCode = result.verifyCode;
      //       this.doPost();
      //     }, () => { });
      //   })
      //   .catch((err) => this.toasty.error(this.translate.instant('An error occurred, please recheck your phone number!')));
    } else if (this.userInfo.paymentMethod === 'stripe') {
      const name = this.stripeTest.get('cardName').value;
      if (!name) {
        return this.toasty.error(this.translate.instant('Please enter card holder name!'));
      }
      this.stripeService
        .createToken(this.card.getCard(), { name })
        .subscribe(result => {
          if (result.token) {
            // Use the token to create a charge or a customer
            // https://stripe.com/docs/charges
            this.stripeToken = result.token.id;
            this.doPost();
          } else if (result.error) {
            // Error creating the token
            this.toasty.error(this.translate.instant('Something went wrong, please try again!'));
          }
        });
    } else {
      // TODO - implement me
      this.doPost();
    }
  }

  callBoth() {
    this.getToken();
    this.changeTab();
  }

  doPost() {
    const products = this.cart.products.map(item => _.pick(item, ['productId', 'productVariantId', 'quantity', 'userNote']));

    this.userInfo.phoneNumber = `${this.dialCode}${this.phoneNumber}`;
    this.cartService.checkout({
      products,
      firstName: this.userInfo.firstName,
      lastName: this.userInfo.lastName,
      email: this.userInfo.email,
      phoneNumber: this.userInfo.phoneNumber,
      streetAddress: this.userInfo.streetAddress,
      city: this.userInfo.city,
      state: this.userInfo.state,
      country: this.userInfo.country,
      shippingAddress: this.userInfo.streetAddress,
      userCurrency: this.userInfo.userCurrency,
      phoneVerifyCode: this.userInfo.phoneVerifyCode ,
      paymentMethod: this.userInfo.paymentMethod,
      zipCode: this.userInfo.zipCode ? this.userInfo.zipCode : '54000'
    })
      .then((resp) => {
        this.checkoutResponse = resp.data;
        if (this.userInfo.paymentMethod === 'cod') {
          this.cartService.clean();
          this.changeTab();
          // window.location.href = '/cart/checkout/success';
        } else if (this.userInfo.paymentMethod === 'paypal') {
          this.transactionService.request({
            gateway: 'paypal',
            service: 'order',
            itemId: resp.data._id
          })
            .then(transactionResp => {
              // this.cartService.clean();
              window.location.href = transactionResp.data.redirectUrl;
            })
            .catch((err) => this.toasty.error(this.translate.instant('Something went wrong, please try again!')));
        } else if (this.userInfo.paymentMethod === 'stripe') {
          this.transactionService.request({
            gateway: 'stripe',
            service: 'order',
            itemId: resp.data._id,
            stripeToken: this.stripeToken,
          })
            .then(res => {
              this.isSpinnerVisible = true;
              this.cartService.clean();
              this.changeTab();
              this.isSpinnerVisible = false;

              const params = Object.assign({
                page: this.page,
                take: this.take,
                sort: `${this.sortOption.sortBy}`,
                sortType: `${this.sortOption.sortType}`
              }, this.searchField);

              this.orderService.find(params).then((res) => {
                this.orders = res.data.items;
                this.total = res.data.count;
                this.lastOrder = this.orders[0];
                console.log(this.orders);
                console.log(this.lastOrder);
              });
              // window.location.href = '/cart/checkout/success';
            })
            .catch((err) => this.toasty.error(this.translate.instant('Something went wrong, please try again!')));
        } else {
          // this.cartService.clean();
          // window.location.href = '/cart/checkout/success';
        }
      })
      .catch(err => this.toasty.error(this.translate.instant('Something went wrong, please try again!')));
  }

  onlyNumberKey(event) {
    return (event.charCode === 8 || event.charCode === 0) ? null : event.charCode >= 48 && event.charCode <= 57;
  }

  selectDial(event) {
    this.dialCode = event;
  }

// Product section implementation
  query() {
    if (this.options.productId) {
      this.relatedQuery();
    } else {
      this.featuredQuery();
    }
  }

  featuredQuery() {
    const params = Object.assign({
      page: this.page,
      take: this.itemsPerPage,
      sort: this.sort,
      sortType: this.sortType
    }, this.options);

    this.productService.search(params).then((res) => {
      this.items = res.data.items;
    });
  }

  relatedQuery() {
    const params = {
      page: this.page,
      take: this.itemsPerPage
    };

    this.productService.related(this.options.productId, params).then((res) => {
      this.items = res.data;
    });
  }

  userAddresses() {
    this.auth.getUserAddresses().then((resp) => {
      this.userAllAddress = resp.data;
      console.log(this.userAllAddress);
    });
  }

  //  order() {
  //   const params = Object.assign({
  //     page: this.page,
  //     take: this.take,
  //     sort: `${this.sortOption.sortBy}`,
  //     sortType: `${this.sortOption.sortType}`
  //   }, this.searchField);
  //
  //   this.orderService.find(params).then((res) => {
  //     this.orders = res.data.items;
  //     this.total = res.data.count;
  //     this.lastOrder = this.orders[0];
  //     console.log(this.orders);
  //     console.log(this.lastOrder);
  //   })
  //     .catch(() => this.toasty.error(this.translate.instant('Something went wrong, please try again!')));
  // }

  // userAddresses() {
  //   let params = Object.assign({
  //     page: this.page,
  //     take: this.itemsPerPage
  //   }, this.searchFields);
  //
  //   this.auth.getUserAddresses().then((resp) => {
  //     this.userAllAddress = resp;
  //     console.log(this.userAllAddress);
  //   });
  // }

//  tabs functions here
//   public ship() {
//     this.isShipping = true;
//   }

  // onLinkClick(event: MatTabChangeEvent) {
  //   console.log('event => ', event);
  //   console.log('index => ', event.index);
  //   console.log('tab => ', event.tab);
  //   // this.isShipping = event.index;
  //   // console.log(this.isShipping);
  //
  //   console.log(event.tab.textLabel);
  //   if (event.index === 0 || event.index === 1) {
  //     this.isShipping = true;
  //   } else {
  //     this.isShipping = false;
  //   }
  //   if (event.index === 2) {
  //     this.isOrder = true;
  //   }
  //
  // }

}
