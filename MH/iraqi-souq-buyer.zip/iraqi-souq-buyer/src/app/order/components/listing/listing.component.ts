import {Component, Input, OnInit} from '@angular/core';
import { OrderService } from '../../services/order.service';
import { Router, ActivatedRoute } from '@angular/router';
import { ToastyService } from 'ng2-toasty';
import { TranslateService } from '@ngx-translate/core';
import * as _ from 'lodash';
import {ProductVariantService} from '../../../product/services/variant.service';
import {CartService} from '../../../shared/services/cart.service';
import {ProductService} from '../../../product/services/product.service';
import {ModalDismissReasons, NgbModal, NgbModalOptions, NgbModalRef} from '@ng-bootstrap/ng-bootstrap';
import {RefundModalComponent} from '../refundModal/refund-modal.component';
import {ReviewService} from '../../../shared/services/review.service';

@Component({
  selector: 'order-listing',
  templateUrl: './listing.html',
  styleUrls: ['./../../order.css']
})
export class ListingComponent implements OnInit {

  @Input() options: any = {};
  public orders = [];
  public page: Number = 1;
  public productId: any;
  public take: Number = 10;
  public total: Number = 0;
  public searchFields: any = {
    status: ''
  };
  public variants: any = [];
  public isVariant = false;
  public stockQuantity = 0;
  public product: any;
  public selectedVariant: any;
  public quantity = 1;

  public itemsPerPage: any = 8;
  public sort: any = 'random';
  public sortType: any = '';
  public items: any = [];

  public sortOption = {
    sortBy: 'createdAt',
    sortType: 'desc'
  };
  private modalReference: NgbModalRef;

  constructor(private variantService: ProductVariantService, private translate: TranslateService, private router: Router, private orderService: OrderService,
              private toasty: ToastyService,
              private cartService: CartService,
              private productService: ProductService,
              private modalService: NgbModal,
              private reviewService: ReviewService) {
  }

  ngOnInit() {
    this.query();
    this.productFunc();
  }

  productFunc() {
    const params = Object.assign({
      page: this.page,
      take: this.itemsPerPage,
      sort: this.sort,
      sortType: this.sortType
    }, this.searchFields);

    this.productService.search(params).then((res) => {
      this.product = res.data.items;
      console.log(this.product);
    });
  }

  query() {
    const params = Object.assign({
      page: this.page,
      take: this.take,
      sort: `${this.sortOption.sortBy}`,
      sortType: `${this.sortOption.sortType}`
    }, this.searchFields);

    this.orderService.find(params).then((res) => {
      this.orders = res.data.items;
      this.total = res.data.count;
      console.log(this.orders);
    })
      .catch(() => this.toasty.error(this.translate.instant('Something went wrong, please try again!')));
  }

  sortBy(field: string, type: string) {
    this.sortOption.sortBy = field;
    this.sortOption.sortType = type;
    this.query();
  }

  getVariants() {
    this.variantService.search(this.product._id, { take: 100 }).then((resp) => {
      this.variants = resp.data.items;
      if (this.variants.length) {
        this.isVariant = true;
        this.selectedVariant = this.variants[0];
        this.variants[0].isSelected = true;
        // this.setPrice(this.variants[0]);
      }
    });
  }

  selectVariant(val: any, index: any) {
    this.isVariant = true;
    if (this.selectedVariant) {
      this.selectedVariant.isSelected = false;
    }
    this.selectedVariant = val;
    this.variants[index].isSelected = true;
    // this.setPrice(this.variants[index]);
  }

  addCart() {
    this.product.forEach( (product) => {
      if (this.variants.length && !this.isVariant) {
        return this.toasty.error(this.translate.instant('Please select a variant option.'));
      }

      if (!product.stockQuantity) {
        return this.toasty.error(this.translate.instant('This item is out of stock.'));
      }
      this.cartService.add({
        productId: this.isVariant ? this.selectedVariant.productId : product._id,
        productVariantId: this.isVariant ? this.selectedVariant._id : null,
        product: product
      }, this.quantity);
    });
    this.router.navigate(['/cart/checkout']);
  }

  changeStatus(status: any) {
    this.searchFields.status = status;
    this.query();
  }
  openRefund(items) {
    const ngbModalOptions: NgbModalOptions = {
      backdrop: 'static',
      keyboard: false
    };
    const modalRef = this.modalService.open(RefundModalComponent, ngbModalOptions);
    modalRef.componentInstance.orderDetailId = items._id;
  }

  open(content) {
    // this.modalService.open(content);
    this.modalReference = this.modalService.open(content);
    // this.modalReference.result.then((result) => {
    //   this.closeResult = `Closed with: ${result}`;
    // }, (reason) => {
    //   this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;

  }
  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return  `with: ${reason}`;
    }
  }

}
