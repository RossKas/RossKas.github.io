import { Component, OnInit } from '@angular/core';
import { CategoryService, ProductService } from '../../services';
import { CartService } from '../../../shared/services';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-product-categories',
  templateUrl: './product-categories.component.html',
  styleUrls: ['./product-categories.component.css']
})
export class ProductCategoriesComponent implements OnInit {
  public tree: any = [];

  constructor(private categoryService: CategoryService,
    private cartService: CartService,
    private productService: ProductService,
    private router: Router,
    private route: ActivatedRoute) { }

  ngOnInit() {
    this.categoryService.tree()
      .then(resp => {
        this.tree = resp;
      });
  }

  searchCat(item: any) {
    // nativate to search page
    this.router.navigate(['/products/search'], {
      queryParams: { categoryId: item._id }
    });
  }

}
