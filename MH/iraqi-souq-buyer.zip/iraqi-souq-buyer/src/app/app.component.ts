import { Component, OnInit, OnDestroy } from '@angular/core';
import { AuthService, SeoService, SystemService } from './shared/services';
import { Router, NavigationEnd } from '@angular/router';
import { Subscription } from 'rxjs/Subscription';
import { TranslateService } from '@ngx-translate/core';
import { CategoryService } from "./product/services/category.service";

import {MenuItem} from 'primeng/api';

declare var $: any;

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit, OnDestroy {
  public title = 'app';
  public tree: any = [];

  items: MenuItem[];

  // header sidebar functionality
  private _opened: boolean = false;
  private _modeNum: number = 0;
  private _positionNum: number = 0;
  private _dock: boolean = false;
  private _closeOnClickOutside: boolean = true;
  private _closeOnClickBackdrop: boolean = false;
  private _showBackdrop: boolean = false;
  private _animate: boolean = true;
  private _trapFocus: boolean = true;
  private _autoFocus: boolean = true;
  private _keyClose: boolean = false;
  private _autoCollapseHeight: number = null;
  private _autoCollapseWidth: number = null;

  private _MODES: Array<string> = ['push', 'over', 'slide'];
  private _POSITIONS: Array<string> = ['left', 'right', 'top', 'bottom'];


  private seoChangedSubscription: Subscription;
  private userLoadedSubscription: Subscription;
  public q: string = '';
  public isShowed: boolean = false;
  public currentUser: any;
  constructor(private router: Router, private categoryService: CategoryService, private authService: AuthService, private seoService: SeoService,
    private translate: TranslateService, private systemService: SystemService) {
    this.userLoadedSubscription = authService.userLoaded$.subscribe(data => this.currentUser = data);
    this.seoChangedSubscription = seoService.seoChanged$.subscribe(data => {
      if (!data) { return; }
      if (data.title) {
        document.title = data.title;
      }
      if (data.meta) {
        $('meta[name="description"]').attr('content', data.meta.description);
        $('meta[name="keywords"]').attr('content', data.meta.description);
      }
    });

    this.router.events.subscribe((event: any) => {
      if (event instanceof NavigationEnd) {
        $('html, body').animate({ scrollTop: 0 });
      }
    });
    const defaultLang = 'en';
    // https://github.com/ngx-translate/core
    translate.setDefaultLang(defaultLang);
    systemService.configs().then(resp => {
      translate.setDefaultLang(resp.i18n.defaultLanguage);
      translate.use(resp.userLang);

      //change favicon
      $('#favicon').attr('href', resp.siteFavicon);
    });
  }

  ngOnInit() {

    // Mega menu jquery //
    $('document').ready(function (){
      $('.home-menu li').hover(function (){
        $('.home-menu li').removeClass('is-active');
        $(this).addClass('is-active');

        $('.side-menu-wide').hide();
        $('.' + $(this).data('menu')).show();
      })
    })
    // Mega menu jquery //

    if (this.authService.isLoggedin()) {
      this.authService.getCurrentUser().then(resp => {
        this.currentUser = resp;
        // console.log(this.currentUser);
      });
    }
    this.categoryService.tree()
      .then(resp => {
        this.tree = resp;
        this.renderMenu(resp);
      });
    //  cart service below //
  }

  ngOnDestroy() {
    // prevent memory leak when component destroyed
    this.seoChangedSubscription.unsubscribe();
    this.userLoadedSubscription.unsubscribe();
  }
  search(item: any) {
    // nativate to search page
    if (!item.children) {
      this.router.navigate(['/products/search'], {
        queryParams: { categoryId: item._id }
      });
    }
  }

  renderMenu(tree: any[]) {
    this.items = [];
    if (tree) {
      for (let index = 0; index < tree.length; index++) {
        const element = tree[index];
        if (element.children) {
          const item = {
            label: element.name, items: []
          }; // command: (resp) => { this.search(resp.item); }

          element.children.forEach(child => {
            item.items.push({
              label: child.name,
              routerLink: ['/products/search'], queryParams: { categoryId: child._id }
            });
          });
          this.items.push(item);
        } else {
          const item = {
            label: element.name,
            routerLink: ['/products/search'], queryParams: { categoryId: element._id }
          };
          this.items.push(item);
        }
      }
    }
  }

  logout() {
    this.authService.removeToken();
    // this.router.navigate(['/auth/login']);
    window.location.href = '/';
  }

  dropdown() {
    this.isShowed = !this.isShowed;
  }

  keyPress(event: any) {
    if (event.charCode === 13) {
      this.searchProd();
    }
  }

  searchProd() {
    if (!this.q.trim()) {
      return;
    }

    // nativate to search page
    this.router.navigate(['/products/search'], {
      queryParams: { q: this.q }
    });
  }

  onSubmit() {
    if (!this.q.trim()) {
      return;
    }

    // nativate to search page
    this.router.navigate(['/products/search'], {
      queryParams: { q: this.q }
    });
  }

  public _toggleOpened(): void {
    this._opened = !this._opened;
  }

  private _toggleMode(): void {
    this._modeNum++;

    if (this._modeNum === this._MODES.length) {
      this._modeNum = 0;
    }
  }

  private _toggleAutoCollapseHeight(): void {
    this._autoCollapseHeight = this._autoCollapseHeight ? null : 500;
  }

  private _toggleAutoCollapseWidth(): void {
    this._autoCollapseWidth = this._autoCollapseWidth ? null : 500;
  }

  private _togglePosition(): void {
    this._positionNum++;

    if (this._positionNum === this._POSITIONS.length) {
      this._positionNum = 0;
    }
  }

  private _toggleDock(): void {
    this._dock = !this._dock;
  }

  private _toggleCloseOnClickOutside(): void {
    this._closeOnClickOutside = !this._closeOnClickOutside;
  }

  private _toggleCloseOnClickBackdrop(): void {
    this._closeOnClickBackdrop = !this._closeOnClickBackdrop;
  }

  private _toggleShowBackdrop(): void {
    this._showBackdrop = !this._showBackdrop;
  }

  private _toggleAnimate(): void {
    this._animate = !this._animate;
  }

  private _toggleTrapFocus(): void {
    this._trapFocus = !this._trapFocus;
  }

  private _toggleAutoFocus(): void {
    this._autoFocus = !this._autoFocus;
  }

  private _toggleKeyClose(): void {
    this._keyClose = !this._keyClose;
  }

  private _onOpenStart(): void {
    console.info('Sidebar opening');
  }

  private _onOpened(): void {
    console.info('Sidebar opened');
  }

  private _onCloseStart(): void {
    console.info('Sidebar closing');
  }

  private _onClosed(): void {
    console.info('Sidebar closed');
  }

  private _onTransitionEnd(): void {
    console.info('Transition ended');
  }

  private _onBackdropClicked(): void {
    console.info('Backdrop clicked');
  }

}
